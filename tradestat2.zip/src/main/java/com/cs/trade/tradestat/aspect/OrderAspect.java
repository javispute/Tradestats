package com.cs.trade.tradestat.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cs.trade.tradestat.dao.OrderBookRepository;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBook;
import com.cs.trade.tradestat.model.OrderBookStats;

@Aspect
@Component
@org.springframework.core.annotation.Order(2)
public class OrderAspect {

    private static final Logger logger = LoggerFactory.getLogger(OrderAspect.class);
    @Autowired
    private OrderBookStats orderBookStats;

    @Pointcut("within(com.cs.trade.tradestat.service.OrderBookServiceImpl+)")
    public void businessLogicMethods() {
    }

    @Around("businessLogicMethods()")
    public Object collectStats(ProceedingJoinPoint pjp) throws Throwable {
        Object retVal = pjp.proceed();
        logger.debug(" OrderAspect : " + pjp.getSignature().getName());
        if ("placeOrder".equals(pjp.getSignature().getName())) {
            collectOrderStats(pjp, retVal);
        }
        return retVal;
    }

    public void collectOrderStats(ProceedingJoinPoint pjp, Object retVal) throws Throwable {

        try {
            Order order = (Order) retVal;
            if (order != null) {
                logger.debug("Order placed : {} ", order);
                orderBookStats.updateOrderStats(order.getInstrumentId(), order);
            }
        } catch (ClassCastException e) {
            logger.error(e.getMessage());
        }
    }

    /* This aspect is invoked on book execution */
    @Around("execution(* com.cs.trade.tradestat.dao.OrderBookRepository.executeBook(*))")
    public Object collectExecStats(ProceedingJoinPoint pjp) throws Throwable {

        Object retVal = pjp.proceed();
        try {
            Execution exec = (Execution) pjp.getArgs()[0];
            logger.debug("Execution placed : {}", exec);
            OrderBook book = ((OrderBookRepository) pjp.getTarget()).getOrderBookByInstrument(exec.getInstrumentId());
            orderBookStats.updateExecStats(book.getInstrumentId(), book.getExecutedOrders());
        } catch (ClassCastException e) {
            logger.error(e.getMessage());
        }
        return retVal;
    }

}
