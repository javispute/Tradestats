package com.cs.trade.tradestat.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.ExecutionStats;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBookStats;
import com.cs.trade.tradestat.model.OrderBookStatus;
import com.cs.trade.tradestat.model.OrderReq;
import com.cs.trade.tradestat.model.OrderStats;
import com.cs.trade.tradestat.service.OrderBookService;

@Controller
@RequestMapping("/orderbook")
public class OrderBookController {

    @Autowired
    OrderBookService orderBookService;

    @Autowired
    OrderBookStats orderBookStats;

    @PostMapping("/{instrumentId}")
    @ResponseBody
    public OrderBookStatus openOrderBook(@PathVariable long instrumentId) {
        boolean status = orderBookService.openOrderBook(instrumentId);
        return new OrderBookStatus(instrumentId, status);
    }

    @PutMapping("/{instrumentId}")
    @ResponseBody
    public OrderBookStatus closeOrderBook(@PathVariable long instrumentId) {
        boolean status = orderBookService.closeOrderBook(instrumentId);
        return new OrderBookStatus(instrumentId, status);
    }

    @PostMapping("/order")
    @ResponseBody
    public Order placeOrder(@RequestBody OrderReq order) {
        return orderBookService.placeOrder(order);
    }

    @GetMapping("/order/{orderId}")
    @ResponseBody
    public Order getOrderById(@PathVariable long orderId) {
        return this.orderBookService.getOrderById(orderId);
    }

    @PostMapping("/exec")
    @ResponseBody
    public List<ExecutedOrder> executeOrder(@RequestBody Execution execution) {
        return this.orderBookService.executeBook(execution);
    }

    @GetMapping("/{instrumentId}/orderstats")
    @ResponseBody
    public OrderStats getOrderStats(@PathVariable long instrumentId) {
        return orderBookStats.getOrderStats(instrumentId);
    }

    @GetMapping("/{instrumentId}/execstats")
    @ResponseBody
    public ExecutionStats getOrderExecStats(@PathVariable long instrumentId) {
        return orderBookStats.getOrderExecStats(instrumentId);
    }
}
