package com.cs.trade.tradestat.model;

import java.math.BigDecimal;

import com.cs.trade.tradestat.util.JsonUtil;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class ExecutedOrder extends Order {
	
	private BigDecimal unitExecutionPrice;
	private boolean isValid;
	@JsonIgnore
	private double distributionRatio;
	private long executionQuantity;
	private BigDecimal executionPrice=new BigDecimal(0);
	@JsonIgnore
	private StatisticalQuantity statsCounts;

	public ExecutedOrder(Order order) {
		super(order);
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}

	public void setExecutionQuantity(long execQuantity) {
		this.executionQuantity = execQuantity;
	}

	public void setExecutionPrice(BigDecimal execPrice) {
		this.executionPrice = execPrice;
	}

	public double getDistributionRatio() {
		return distributionRatio;
	}

	public void setDistributionRatio(double distributionRatio) {
		this.distributionRatio = distributionRatio;
	}


	public boolean isValid() {
		return isValid;
	}

	public long getExecutionQuantity() {
		return executionQuantity;
	}

	public BigDecimal getExecutionPrice() {
		return executionPrice;
	}

	public StatisticalQuantity getStatsCounts() {
		return statsCounts;
	}

	public void setStatsCounts(StatisticalQuantity statsCounts) {
		this.statsCounts = statsCounts;
	}

	public String toString() {
		return JsonUtil.toJsonString(this);
	}
	public BigDecimal getUnitExecutionPrice() {
		return unitExecutionPrice;
	}

	public void setUnitExecutionPrice(BigDecimal executionUnitPrice) {
		this.unitExecutionPrice = executionUnitPrice;
	}
}
