package com.cs.trade.tradestat.model;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class OrderBook {

    private long instrumentId;
    private long orderbookId;
    private boolean isOpen;
    private static AtomicLong orderBookIdGenerator = new AtomicLong(1);
    private Lock lock = new ReentrantLock();
    private List<Order> orderEntries = new ArrayList<>();
    private List<ExecutedOrder> executedOrders = new ArrayList<>();

    public OrderBook(long instrumentId, boolean isOpen) {
        this.orderbookId = orderBookIdGenerator.getAndIncrement();
        this.instrumentId = instrumentId;
        this.isOpen = isOpen;
    }

    public void setOpen(boolean status) {
        try {
            lock.lock();
            this.isOpen = status;
        } finally {
            lock.unlock();
        }
    }

    public boolean isOpen() {
        return isOpen;
    }

    public long getInstrumentId() {
        return this.instrumentId;
    }

    public boolean placeOrder(Order order) {
        try {
            lock.lock();
            if (order != null) {
                this.orderEntries.add(order);
                return true;
            }
        } finally {
            lock.unlock();
        }
        return false;
    }

    public long getOrderbookId() {
        return orderbookId;
    }

    public List<Order> getOrders() {
        return new ArrayList<>(this.orderEntries);
    }

    public List<ExecutedOrder> getExecutedOrders() {
        return this.executedOrders;
    }

    public synchronized void addExecOrder(ExecutedOrder lastExecOrder) {
        this.executedOrders.add(lastExecOrder);
    }

    public void lock() {
        this.lock.lock();
    }

    public void unlock() {
        this.lock.unlock();
    }

}
