package com.cs.trade.tradestat.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import com.fasterxml.jackson.annotation.JsonIgnore;

/***
 * This class statistics about the amount of valid/invalid orders in each book, valid/invalid demand, the biggest order
 * and the smallest order, the earliest order entry, the last order entry, limit break down (a table with limit prices
 * and demand per limit price), accumulated execution quantity and execution price
 */
public class ExecutionStats {

    @JsonIgnore
    private boolean init = false;
    private AtomicLong validDemand = new AtomicLong(0);
    private AtomicLong invalidDemand = new AtomicLong(0);

    private AtomicInteger totalValidDemandCount = new AtomicInteger(0);
    private AtomicInteger totalInvalidDemandCount = new AtomicInteger(0);
    private AtomicLong accumulatedQuantiy = new AtomicLong(0);
    private BigDecimal accumulatedPrice = new BigDecimal(0);
    private ExecutedOrder earliestOrder;
    private ExecutedOrder lastOrder;
    private ExecutedOrder biggestOrder;
    private ExecutedOrder smallestOrder;
    @JsonIgnore
    private long biggestQuantity = 0;
    @JsonIgnore
    private long smallestQuantity = Integer.MAX_VALUE;

    public AtomicLong getAccumulatedQuantiy() {
        return accumulatedQuantiy;
    }

    public BigDecimal getAccumulatedPrice() {
        return accumulatedPrice;
    }

    private Map<BigDecimal, AtomicLong> limitPriceDemandMap = new ConcurrentHashMap<>();

    public void updateExecStats(List<ExecutedOrder> execOrders) {
        if (execOrders != null && execOrders.isEmpty() == false) {
            int size = execOrders.size();
            // one time calculation for execution stats
            if (init == false) {
                init = true;
                earliestOrder = execOrders.get(0);
                lastOrder = execOrders.get(size - 1);

                for (ExecutedOrder exOdr : execOrders) {
                    if (exOdr.isValid()) {

                        totalValidDemandCount.incrementAndGet();
                        validDemand.addAndGet(exOdr.getQuantity());
                    } else {
                        totalInvalidDemandCount.incrementAndGet();
                        invalidDemand.addAndGet(exOdr.getQuantity());
                    }
                    if (exOdr.getQuantity() > this.biggestQuantity) {
                        this.biggestQuantity = exOdr.getQuantity();
                        this.biggestOrder = exOdr;
                    }
                    if (exOdr.getQuantity() < this.smallestQuantity) {
                        this.smallestQuantity = exOdr.getQuantity();
                        this.smallestOrder = exOdr;
                    }
                    if (OrderType.LIMIT_ORDER.equals(exOdr.getOrderType())) {
                        AtomicLong quantity = limitPriceDemandMap.get(exOdr.getLimitPrice());
                        if (quantity == null) {
                            quantity = new AtomicLong(exOdr.getQuantity());
                            limitPriceDemandMap.put(exOdr.getLimitPrice(), quantity);
                        } else {
                            quantity.addAndGet(exOdr.getQuantity());
                        }
                    }
                }
            }
            accumulatedQuantiy = new AtomicLong(0);
            accumulatedPrice = new BigDecimal(0);
            for (ExecutedOrder exOdr : execOrders) {
                if (exOdr.isValid()) {
                    accumulatedQuantiy.addAndGet(exOdr.getExecutionQuantity());
                    accumulatedPrice = accumulatedPrice.add(exOdr.getExecutionPrice());
                }
            }

        }
    }

    public AtomicLong getValidDemand() {
        return validDemand;
    }

    public AtomicLong getInvalidDemand() {
        return invalidDemand;
    }

    public AtomicInteger getTotalValidDemandCount() {
        return totalValidDemandCount;
    }

    public AtomicInteger getTotalInvalidDemandCount() {
        return totalInvalidDemandCount;
    }

    public ExecutedOrder getEarliestOrder() {
        return earliestOrder;
    }

    public ExecutedOrder getLastOrder() {
        return lastOrder;
    }

    public ExecutedOrder getBiggestOrder() {
        return biggestOrder;
    }

    public ExecutedOrder getSmallestOrder() {
        return smallestOrder;
    }

    public long getBiggestQuantity() {
        return biggestQuantity;
    }

    public long getSmallestQuantity() {
        return smallestQuantity;
    }

    public Map<BigDecimal, AtomicLong> getLimitPriceDemandMap() {
        return limitPriceDemandMap;
    }

}
