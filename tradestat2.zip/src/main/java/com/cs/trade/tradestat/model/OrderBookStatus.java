package com.cs.trade.tradestat.model;

public class OrderBookStatus {
    private long instrumentId;
    private boolean isOpen;

    public OrderBookStatus(long instrumentId, boolean isOpen) {
        this.instrumentId = instrumentId;
        this.isOpen = isOpen;
    }

    public boolean isOpen() {
        return isOpen;
    }

    public long getInstrumentId() {
        return instrumentId;
    }

}
