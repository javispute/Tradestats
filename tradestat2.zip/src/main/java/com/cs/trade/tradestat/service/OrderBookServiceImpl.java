package com.cs.trade.tradestat.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cs.trade.tradestat.dao.OrderBookRepository;
import com.cs.trade.tradestat.exception.CloseBookException;
import com.cs.trade.tradestat.exception.NoNewExecutionExceptedException;
import com.cs.trade.tradestat.exception.NoOrderFoundException;
import com.cs.trade.tradestat.exception.NoSuchBookExistsException;
import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBook;
import com.cs.trade.tradestat.model.OrderReq;

@Service
public class OrderBookServiceImpl implements OrderBookService {

    @Autowired
    private OrderBookRepository orderBookRepo;

    @Override
    public boolean openOrderBook(long instrumentId) {
        OrderBook orderBook = orderBookRepo.getOrderBookByInstrument(instrumentId);
        if (orderBook == null) {
            return this.orderBookRepo.openOrderBook(instrumentId);
        }
        if (orderBook.isOpen() == false) {
            throw new CloseBookException("OrderBook is closed for instrument : " + instrumentId);
        }
        return orderBook.isOpen();
    }

    @Override
    public boolean closeOrderBook(long instrumentId) {

        OrderBook orderBook = validateBookExists(instrumentId);
        if (orderBook.isOpen()) {
            return this.orderBookRepo.closeOrderBook(instrumentId);
        }
        return false;
    }

    @Override
    public Order placeOrder(OrderReq orderReq) {
        if (orderReq != null) {
            long instrumentId = orderReq.getInstrumentId();
            validateBookAndStatus(instrumentId, false, new CloseBookException("Order Book is closed for instrument : " + instrumentId));
            Order newOrder = Order.getInstance(orderReq);
            orderBookRepo.placeOrder(newOrder);
            return newOrder;
        }
        throw new IllegalArgumentException("Order request can't be null, needs minimum orderbookid, quantity in order request.");
    }

    @Override
    public Order getOrderById(long orderId) {
        Order order = this.orderBookRepo.getOrderById(orderId);
        if(order != null) {
          return order ;
        }
        throw new NoOrderFoundException("No order exists for order id :"+orderId);
    }

    @Override
    public List<ExecutedOrder> executeBook(Execution execution) {
        validateBookAndStatus(execution.getInstrumentId(), true, new NoNewExecutionExceptedException("Book is open, book can't be executed."));
        return this.orderBookRepo.executeBook(execution);
    }

    public void setOrderBookRepo(OrderBookRepository orderBookRepo) {
        this.orderBookRepo = orderBookRepo;
    }

    private OrderBook validateBookExists(long id) {
        OrderBook orderBook = null;
        orderBook = orderBookRepo.getOrderBookByInstrument(id);
        if (orderBook == null) {
            throw new NoSuchBookExistsException("No book exists for instrument :" + id);
        }
        return orderBook;

    }

    private void validateBookAndStatus(long instrumentId, boolean bookStatusShouldNotBe, RuntimeException ex) {
        OrderBook orderBook = validateBookExists(instrumentId);
        if (orderBook.isOpen() == bookStatusShouldNotBe) {
            throw ex;
        }
    }

}
