package com.cs.trade.tradestat.model;

public class StatisticalQuantity {
    private long roundQty;
    private long ceilQty;
    private long floorQty;

    public StatisticalQuantity(long rt, long ct, long ft) {
        this.roundQty = rt;
        this.ceilQty = ct;
        this.floorQty = ft;
    }

    public long getRoundQty() {
        return roundQty;
    }

    public void setRoundQty(long roundTotal) {
        this.roundQty = roundTotal;
    }

    public long getCeilQty() {
        return ceilQty;
    }

    public void setCeilQty(long ceilTotal) {
        this.ceilQty = ceilTotal;
    }

    public long getFloorQty() {
        return floorQty;
    }

    public void setFloorQty(long floorTotal) {
        this.floorQty = floorTotal;
    }
}
