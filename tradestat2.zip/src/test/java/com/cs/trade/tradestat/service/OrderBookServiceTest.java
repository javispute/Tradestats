package com.cs.trade.tradestat.service;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cs.trade.tradestat.dao.OrderBookRepository;
import com.cs.trade.tradestat.dao.OrderBookRepositoryImpl;
import com.cs.trade.tradestat.exception.CloseBookException;
import com.cs.trade.tradestat.exception.NoNewExecutionExceptedException;
import com.cs.trade.tradestat.exception.NoSuchBookExistsException;
import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBook;
import com.cs.trade.tradestat.model.OrderReq;
import com.cs.trade.tradestat.model.OrderType;
import com.cs.trade.tradestat.util.BeanCreationUtil;

@RunWith(SpringJUnit4ClassRunner.class)
public class OrderBookServiceTest {

    OrderBookRepository repo = Mockito.mock(OrderBookRepositoryImpl.class);

    OrderBookServiceImpl svc = new OrderBookServiceImpl();

    static long instrumentId = 1234;
    static long orderbookId;

    OrderBook orderBook = new OrderBook(instrumentId,true);
    
    public OrderBookServiceTest() {
        this.svc.setOrderBookRepo(repo);
    }

    @Before
    public void openOrderBook() {
        when(this.repo.getOrderBookByInstrument(instrumentId)).thenReturn(null);
        when(this.repo.openOrderBook(instrumentId)).thenReturn(true);
        assertThat(this.svc.openOrderBook(instrumentId), equalTo(true));
    }

    @Test
    public void testCloseBook() {
        when(this.repo.getOrderBookByInstrument(instrumentId)).thenReturn(orderBook);
        when(this.repo.closeOrderBook(1l)).thenReturn(false);
        assertThat(false, equalTo(this.svc.closeOrderBook(instrumentId)));
    }

    @Test(expected = NoSuchBookExistsException.class)
    public void testCloseBook_withoutOpeningIt() {
        when(this.repo.getOrderBookByInstrument(2345)).thenReturn(null);
        when(this.repo.closeOrderBook(2345)).thenThrow(new NoSuchBookExistsException("No Such book exists : " + instrumentId));
        this.svc.closeOrderBook(2345);
    }

    /*
     * @Test(expected = NoSuchBookExistsException.class) public void testIsBookOpen_UnknowInstrument() {
     * when(this.repo.isOrderBookOpen(2345)).thenThrow(new NoSuchBookExistsException("No such book exists"));
     * this.svc.isOrderBookOpen(2345); }
     */

    @Test
    public void testPlaceOrderForOpenBook() {
        when(this.repo.placeOrder(Mockito.any())).thenReturn(true);
        when(this.repo.getOrderBookByInstrument(instrumentId)).thenReturn(orderBook);
        OrderReq orderReq = BeanCreationUtil.createMarketOrderReq(instrumentId, 50);
        Order order = this.svc.placeOrder(orderReq);
        assertThat(order, is(notNullValue()));
        assertThat(orderReq.getInstrumentId(), equalTo(order.getInstrumentId()));
        assertThat(orderReq.getQuantity(), equalTo(order.getQuantity()));
        assertThat(OrderType.MARKET_ORDER, equalTo(order.getOrderType()));
    }

    @Test(expected = CloseBookException.class)
    public void testPlaceOrderForCloseBook() {
        orderBook.setOpen(false);
        when(this.repo.getOrderBookByInstrument(instrumentId)).thenReturn(orderBook);
        OrderReq orderReq = BeanCreationUtil.createMarketOrderReq(instrumentId, 50);
        this.svc.placeOrder(orderReq);
    }

    @Test(expected = NoSuchBookExistsException.class)
    public void testPlaceOrderForNonExistingBook() {
        when(this.repo.placeOrder(Mockito.any())).thenThrow(new NoSuchBookExistsException("No book exists for instrument :" + 2345));
        OrderReq orderReq = BeanCreationUtil.createMarketOrderReq(2345, 50);
        this.svc.placeOrder(orderReq);
    }

   

    @Test
    public void testGetOrderById() {
        Order order = BeanCreationUtil.createMarketPriceOrder(instrumentId, 50);
        when(this.repo.getOrderById(order.getOrderId())).thenReturn(order);
        Order ordr = this.svc.getOrderById(order.getOrderId());
        assertThat(ordr, equalTo(order));
    }

  
    @Test
    public void testExecuteBook() {
        orderBook.setOpen(false);
        when(this.repo.getOrderBookByInstrument(instrumentId)).thenReturn(orderBook);
        Execution execution = BeanCreationUtil.createExecution(instrumentId, 100, 50);
        List<ExecutedOrder> exOrdrs = getExecOrderList();
        when(this.repo.executeBook(execution)).thenReturn(exOrdrs);
        List<ExecutedOrder> exordrList = this.svc.executeBook(execution);
        assertThat(exordrList, hasSize(2));
        assertThat(exordrList, equalTo(exOrdrs));

    }

    @Test(expected = NoNewExecutionExceptedException.class)
    public void testExecuteBookForOpenBook() {
        when(this.repo.getOrderBookByInstrument(instrumentId)).thenReturn(orderBook);
        Execution execution = BeanCreationUtil.createExecution(instrumentId, 100, 50);
        when(this.repo.executeBook(Mockito.any())).thenThrow(new NoNewExecutionExceptedException("Book is open, book can't be executed."));
        this.svc.executeBook(execution);
    }

    private List<ExecutedOrder> getExecOrderList() {
        List<ExecutedOrder> orders = new ArrayList<>();
        Order order = BeanCreationUtil.createMarketPriceOrder(instrumentId, 50);
        Order order2 = BeanCreationUtil.createLimitPriceOrder(instrumentId, 80, 25);
        orders.add(new ExecutedOrder(order));
        orders.add(new ExecutedOrder(order2));
        return orders;
    }

    

}
