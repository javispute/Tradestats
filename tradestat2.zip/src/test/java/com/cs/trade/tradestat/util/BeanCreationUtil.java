/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2019. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.cs.trade.tradestat.util;

import java.math.BigDecimal;
import java.util.Date;

import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderReq;
import com.cs.trade.tradestat.model.OrderType;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class BeanCreationUtil {


	public static Order createMarketPriceOrder(final long instrumentId, long qty) {
		return Order.getInstance(instrumentId,qty, new Date());
	}


	public static Order createLimitPriceOrder(final long instrumentId, long qty , double price) {
		BigDecimal orderPrice = new BigDecimal(price);
		return Order.getInstance(instrumentId, qty, new Date(), orderPrice, OrderType.LIMIT_ORDER);
	}

	public static Execution createExecution(long instrumentId, long quantity, long price) {
		Execution exec = new Execution();
		exec.setInstrumentId(instrumentId);
		exec.setQuantity(quantity);
		exec.setPrice(new BigDecimal(price));
		return exec;
	}

	public static Order createMarketOrder(long instrumentId, long quantity) {
		return Order.getInstance(createMarketOrderReq(instrumentId, quantity));
	}
	public static OrderReq createMarketOrderReq(long instrumentId, long quantity) {
		OrderReq oreq = new OrderReq();
		oreq.setInstrumentId(instrumentId);
		oreq.setQuantity(quantity);
		System.out.println(JsonUtil.toJsonString(oreq));
		return oreq;
		
	}
	
	public static OrderReq createLimitOrderReq(long instrumentId, long quantity, double price) {
            OrderReq oreq = new OrderReq();
            oreq.setInstrumentId(instrumentId);
            oreq.setQuantity(quantity);
            oreq.setLimitPrice(new BigDecimal(price));
            oreq.setOrderType(OrderType.LIMIT_ORDER);
            System.out.println(JsonUtil.toJsonString(oreq));
            return oreq;
            
    }

}
