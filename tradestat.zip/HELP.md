**Open OrderBook**
----
  
* **URL**

    /orderbook/{:instrumentId}

* **Method:**
  
     `POST` 
  
*  **URL Params**

   
   **Required:**
 
      `instrumentId=[long]`

*  **Optional:**
 
      None


* **Success Response:**
  
   * **Code:** 
   
              200
   * **Content:** 
   
            {
               "orderbookId": 12,
                "open": true 
           } 
 
* **Error Response:**
     
      None
  
* **Sample Call:**

       url: "/orderbook/12345", 

* **Notes:**

           Open Orderbook call can be made multiple times without any impact util its open.
           Once orderbook is closed it cant be opened. 
----


**Close OrderBook**

  
* **URL**

    /orderbook/{:orderbookId}

* **Method:**
  
     `PUT` 
  
*  **URL Params**

   
   **Required:**
 
      `orderbookId=[long]`

*  **Optional:**
 
      None


* **Success Response:**
  
   * **Code:** 
     
              200
   * **Content:** 
   
            {
               "orderbookId": 12,
                "open": false 
           } 
 
* **Error Response:**
     
      None
  
* **Sample Call:**

       url: "/orderbook/12", 

* **Notes:**

         Close orderbook can be called any number time after its closed without any impact.
         Once book is closed it cant be opened.
 
----

** Place Order**
----
  
* **URL**

     /orderbook/order
     
      

* **Method:**
  
     `POST` 
  
*  **Request Body **
         
          { "orderbookId"=":orderbookId", "quantity"=":quantity","limitPrice"=":limitPrice","orderType"="LIMIT_ORDER"}
        or   
          { "orderbookId"=":orderbookId", "quantity"=":quantity","orderType"="MARKET_ORDER"}
   
*   **Required:**
 
     `orderbookId=[long]`
      `quantity=[long]`

*  **Optional:**
 
      `limitPrice=[BigDecimal]`
      `orderType=[LIMIT_ORDER | MARKET_ORDER ]`


* **Success Response:**
  
   * **Code:** 
         
           200 
   * **Content:** 
   
			 `{
			    "orderId": 5,
			    "orderbookId": 1234,
			    "quantity": 50,
			    "limitPrice": null,
			    "orderType": "MARKET_ORDER"
			  }`
 
* **Error Response:**
     
      {
         "timestamp": "2019-04-13T02:33:39.129+0000",
         "status": 500,
          "error": "Internal Server Error",
          "message": "Order Book is closed for instrument : 1234",
           "path": "/orderbook/order"
        }
  
* **Sample Call:**

     url: "/orderbook/order 
    
* **Notes:**
     
     Please note if only instrument id and quantity is provided then by default it's MARKET_ORDER type.
     Order can be placed only and only if the order book is open for instrument.
 
 
---- 


** View Order By Order Id**
----
  
* **URL**

     /orderbook/order/{orderId}

* **Method:**
  
     `GET` 
  
*  **Path Params**

   
*    **Required:**
 
     `orderId=[long]`
      

*   **Optional:**
 
      `None`


* **Success Response:**
  
   * **Code:** 
   
            200 
   * **Content:** 
     
					{
					    "orderId": 1,
					    "instrumentId": 1234,
					    "quantity": 750,
					    "limitPrice": null,
					    "orderType": "MARKET_ORDER",
					    "unitExecutionPrice": null,
					    "executionQuantity": 0,
					    "executionPrice": 0,
					    "valid": false
					}
					      
* **Error Response:**
     
      None
  
* **Sample Call:**

    url: "/orderbook/order/1 
        
* **Notes:**  
 
     Please note the valid, execution Quantity , executionPrice, UnitExecutionPrice etc fields can have default value if book is not executed. 
     Once book is executed they will be populated according to execution.

----


** Execute Order**
  
* **URL**

     /orderbook/exec

* **Method:**
  
     `POST` 
  
*  **Request Body**
 
             '{"orderbookId:"1234","quantity":"2500","price":"450"}'
        
*    **Required:**
 
     `orderbookId=[long]`
     `quantity=[long]`
     `price=[BigDecimal]`
      

*   **Optional:**
 
      `None`


* **Success Response:**
  
   * **Code:** 
   
            200 
   * **Content:** 
     
		 [
			    {
			        "orderId": 1,
			        "orderbookId": 1234,
			        "quantity": 40,
			        "limitPrice": 20,
			        "orderType": "LIMIT_ORDER",
			        "unitExecutionPrice": 20,
			        "executionQuantity": 40,
			        "executionPrice": 800,
			        "valid": true
			    },
			    {
			        "orderId": 2,
			        "orderbookId": 1234,
			        "quantity": 50,
			        "limitPrice": 16,
			        "orderType": "LIMIT_ORDER",
			        "unitExecutionPrice": 20,
			        "executionQuantity": 0,
			        "executionPrice": 0,
			        "valid": false
			    },
			    {
			        "orderId": 3,
			        "orderbookId": 1234,
			        "quantity": 50,
			        "limitPrice": null,
			        "orderType": "MARKET_ORDER",
			        "unitExecutionPrice": 20,
			        "executionQuantity": 50,
			        "executionPrice": 1000,
			        "valid": true
			    },
			]    
      
* **Error Response:**
     
      {
		    "timestamp": "2019-04-13T02:33:39.129+0000",
		    "status": 500,
		    "error": "Internal Server Error",
		    "message": "Book is open, book can't be executed.",
		    "path": "/orderbook/exec"
		}
  
* **Sample Call:**

    url: "/orderbook/exec
        
* **Notes:**   
     
      Order execution can be accepted if book is closed for instrument.
      if quantity in execution is less than total demand, then quantity is distributed based ratio individual order demand / total demand.
      
-----


** View Order stats**
----
  
* **URL**

     /orderbook/{orderbookId}/orderstats

* **Method:**
  
     `GET` 
  
*  **Path Params**

   
*    **Required:**
 
     `orderbookId=[long]`
      

*   **Optional:**
 
      `None`


* **Success Response:**
  
   * **Code:** 
   
            200 
   * **Content:** 
     
				{
				    "totalOrderCount": 4,
				    "totalDemand": 190,
				    "biggestOrder": {
				        "orderId": 2,
				        "orderbookId": 1234,
				        "quantity": 50,
				        "limitPrice": 16,
				        "orderType": "LIMIT_ORDER"
				    },
				    "smallestOrder": {
				        "orderId": 1,
				        "orderbookId": 1234,
				        "quantity": 40,
				        "limitPrice": 16,
				        "orderType": "LIMIT_ORDER"
				    },
				    "earliestOrder": {
				        "orderId": 1,
				        "orderbookId": 1234,
				        "quantity": 40,
				        "limitPrice": 16,
				        "orderType": "LIMIT_ORDER"
				    },
				    "lastOrder": {
				        "orderId": 5,
				        "orderbookId": 1234,
				        "quantity": 50,
				        "limitPrice": null,
				        "orderType": "MARKET_ORDER"
				    },
				    "limitPriceDemandMap": {
				        "16": 90
				    }
				}      
* **Error Response:**
     
      None
  
* **Sample Call:**

    url: "/orderbook/1234/orderstats 
        
* **Notes:**   

----

** View Order Execution stats**
----
  
* **URL**

     /orderbook/{orderbookId}/execstats

* **Method:**
  
     `GET` 
  
*  **Path Params**

   
*    **Required:**
 
     `orderbookId=[long]`
      

*   **Optional:**
 
      `None`


* **Success Response:**
  
   * **Code:** 
   
            200 
   * **Content:** 
     
				{
				    "validDemand": 1750,
				    "invalidDemand": 500,
				    "totalValidDemandCount": 3,
				    "totalInvalidDemandCount": 1,
				    "accumulatedQuantiy": 1670,
				    "accumulatedPrice": 125250,
				    "earliestOrder": {
				        "orderId": 1,
				        "orderbookId": 1234,
				        "quantity": 750,
				        "limitPrice": null,
				        "orderType": "MARKET_ORDER",
				        "unitExecutionPrice": 75,
				        "executionQuantity": 716,
				        "executionPrice": 53700,
				        "valid": true
				    },
				    "lastOrder": {
				        "orderId": 4,
				        "orderbookId": 1234,
				        "quantity": 500,
				        "limitPrice": 70,
				        "orderType": "LIMIT_ORDER",
				        "unitExecutionPrice": 75,
				        "executionQuantity": 0,
				        "executionPrice": 0,
				        "valid": false
				    },
				    "biggestOrder": {
				        "orderId": 1,
				        "orderbookId": 1234,
				        "quantity": 750,
				        "limitPrice": null,
				        "orderType": "MARKET_ORDER",
				        "unitExecutionPrice": 75,
				        "executionQuantity": 716,
				        "executionPrice": 53700,
				        "valid": true
				    },
				    "smallestOrder": {
				        "orderId": 2,
				        "orderbookId": 1234,
				        "quantity": 500,
				        "limitPrice": null,
				        "orderType": "MARKET_ORDER",
				        "unitExecutionPrice": 75,
				        "executionQuantity": 477,
				        "executionPrice": 35775,
				        "valid": true
				    },
				    "limitPriceDemandMap": {
				        "70": 500,
				        "75": 500
				    }
				}    
* **Error Response:**
     
      None
  
* **Sample Call:**

    url: "/orderbook/1234/execstats 
        
* **Notes:**