package com.cs.trade.tradestat;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.cs.trade.tradestat.controller.OrderBookControllerTest;
import com.cs.trade.tradestat.dao.LinerExecutionDistributionStrategyTest;
import com.cs.trade.tradestat.dao.OrderBookRepositoryTest;
import com.cs.trade.tradestat.service.OrderBookServiceTest;

@RunWith(Suite.class)
@SuiteClasses({OrderBookControllerTest.class,OrderBookServiceTest.class,OrderBookRepositoryTest.class, LinerExecutionDistributionStrategyTest.class})
public class TestSuit {

}
