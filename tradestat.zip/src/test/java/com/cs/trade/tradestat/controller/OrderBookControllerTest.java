package com.cs.trade.tradestat.controller;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;

import com.cs.trade.tradestat.dao.LinerExecutionDistributionStrategy;
import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.ExecutionStats;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBook;
import com.cs.trade.tradestat.model.OrderBookStats;
import com.cs.trade.tradestat.model.OrderReq;
import com.cs.trade.tradestat.model.OrderStats;
import com.cs.trade.tradestat.service.OrderBookService;
import com.cs.trade.tradestat.util.BeanCreationUtil;
import com.cs.trade.tradestat.util.JsonUtil;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class OrderBookControllerTest {
	
    @LocalServerPort
    private int port;
    private static String user = "csuser";
    private static String password = "csuser123";
    private String uri;

    @MockBean
    OrderBookService svc;

    @MockBean
    OrderBookStats stats;

    static long instrumentId = 1234;
    static long orderbookId = 1;

    @PostConstruct
    public void init() {
        uri = "http://localhost:" + port + "/tradestat";
    }

    @Test
    public void testOpenBook() {
        when(svc.openOrderBook(instrumentId)).thenReturn(1l);

        given().auth().preemptive().basic(user, password)
         .when().post(uri + "/orderbook/" + instrumentId )
         .then().assertThat()
                .statusCode(HttpStatus.OK.value())
                .and()
                .body("orderbookId", equalTo(1))
                .and()
                .body("open", equalTo(true));
    }

    @Test
    public void testCloseBook() {
        when(svc.closeOrderBook(instrumentId)).thenReturn(false);
        given().auth().preemptive().basic(user, password)
        .when().put(uri + "/orderbook/" + 1)
        .then().assertThat()
               .statusCode(HttpStatus.OK.value())
               .and()
               .body("orderbookId", equalTo(1))
               .and()
               .body("open", equalTo(false));
    }

    @Test
    public void testPlaceMarketOrder() {
        
        OrderReq oreq =BeanCreationUtil.createMarketOrderReq(orderbookId, 34);
        Order order = Order.getInstance(oreq);
        when(svc.placeOrder(any())).thenReturn(order);

        /*
         * Map<String, String> request = new HashMap<>(); request.put("instrumentId", "1234"); request.put("quantity", "34");
         */

        given().auth().preemptive().basic(user, password)
          .when().contentType("application/json").body(JsonUtil.toJsonString(oreq)).post(uri + "/orderbook/order")
          .then().assertThat()
              .statusCode(HttpStatus.OK.value())
              .assertThat()
              .body("orderbookId", equalTo(1))
              .and()
              .body("quantity", equalTo(34))
              .and()
              .body("orderType", equalTo("MARKET_ORDER"));
    }

    @Test
    public void testPlaceLimitOrder() {

        OrderReq oreq =BeanCreationUtil.createLimitOrderReq(orderbookId, 34,450);
        Order order = Order.getInstance(oreq);
        when(svc.placeOrder(oreq)).thenReturn(order);

        given().auth().preemptive().basic(user, password)
         .when().contentType("application/json").body(JsonUtil.toJsonString(oreq)).post(uri + "/orderbook/order")
         .then().assertThat()
                .statusCode(HttpStatus.OK.value())
                .assertThat()
                 .body("orderbookId", equalTo(1))
                 .and()
                 .body("quantity", equalTo(34))
                 .and()
                 .body("orderType", equalTo("LIMIT_ORDER"))
                 .and()
                 .body("limitPrice", equalTo(450));
        ;
    }

    @Test
    public void testGetOrderById() {

        Order order = BeanCreationUtil.createMarketOrder(orderbookId, 34);

        when(svc.getOrderById(1)).thenReturn(order);

        given().auth().preemptive().basic(user, password)
        .when().get(uri + "/orderbook/order/1")
        .then().assertThat()
        .statusCode(HttpStatus.OK.value())
        .contentType("application/json")
        .assertThat()
          .body("orderbookId", equalTo(1))
          .and()
          .body("quantity", equalTo(34))
          .and()
          .body("orderType", equalTo("MARKET_ORDER"));
    }

   
    @Test
    public void testExecuteBook() {

        Execution execution = BeanCreationUtil.createExecution(instrumentId, 100, 50);
        List<ExecutedOrder> list = new ArrayList<>();

        Order order = BeanCreationUtil.createMarketOrder(instrumentId, 34);
        Order order1 = BeanCreationUtil.createMarketOrder(instrumentId, 50);
        list.add(new ExecutedOrder(order));
        list.add(new ExecutedOrder(order1));

        when(svc.executeBook(execution)).thenReturn(list);

        given().auth().preemptive().basic(user, password).when().contentType("application/json").body(JsonUtil.toJsonString(execution)).post(uri + "/orderbook/exec").then().assertThat()
                .statusCode(HttpStatus.OK.value()).contentType("application/json").assertThat().body("size()", is(2));

    }

    @Test
    public void testGetOrderStats() {

        Order order = BeanCreationUtil.createLimitPriceOrder(instrumentId, 80, 55);
        Order order1 = BeanCreationUtil.createMarketOrder(instrumentId, 50);
        Order order2 = BeanCreationUtil.createLimitPriceOrder(instrumentId, 30, 45);
        OrderStats orderstats = new OrderStats();
        orderstats.updateStats(order);
        orderstats.updateStats(order1);
        orderstats.updateStats(order2);

        when(stats.getOrderStats(instrumentId)).thenReturn(orderstats);

        given().auth().preemptive().basic(user, password).when().get(uri + "/orderbook/" + instrumentId + "/orderstats").then().assertThat()
                .statusCode(HttpStatus.OK.value()).contentType("application/json").assertThat().body("totalOrderCount", is(3)).and()
                .body("earliestOrder.orderId", equalTo((int) order.getOrderId())).and()
                .body("earliestOrder.orderType", equalTo(order.getOrderType().toString())).and()
                .body("lastOrder.orderId", equalTo((int) order2.getOrderId())).and()
                .body("lastOrder.orderType", equalTo(order2.getOrderType().toString()));

    }

    @Test
    public void testGetOrderExecStats() {

        Order order = BeanCreationUtil.createLimitPriceOrder(instrumentId, 80, 55);
        Order order1 = BeanCreationUtil.createMarketOrder(instrumentId, 50);
        Order order2 = BeanCreationUtil.createLimitPriceOrder(instrumentId, 30, 45);

        OrderBook book = new OrderBook(instrumentId,true);
        book.addExecOrder(new ExecutedOrder(order));
        book.addExecOrder(new ExecutedOrder(order1));
        book.addExecOrder(new ExecutedOrder(order2));

        ExecutionStats execStats = new ExecutionStats();

        Execution execution = BeanCreationUtil.createExecution(instrumentId, 100, 55);
        new LinerExecutionDistributionStrategy().executeOrder(book, execution);

        execStats.updateExecStats(book.getExecutedOrders());

        when(stats.getOrderExecStats(instrumentId)).thenReturn(execStats);

        given().auth().preemptive().basic(user, password).when().get(uri + "/orderbook/" + instrumentId + "/execstats").then().assertThat()
                .statusCode(HttpStatus.OK.value()).contentType("application/json").assertThat().body("validDemand", is(130)).and()
                .body("invalidDemand", is(30)).and().body("totalValidDemandCount", is(2)).and().body("totalInvalidDemandCount", is(1)).and()
                .body("accumulatedQuantiy", is(100)).and().body("accumulatedPrice", is(5500)).and()
                .body("earliestOrder.orderId", equalTo((int) order.getOrderId())).and()
                .body("earliestOrder.orderType", equalTo(order.getOrderType().toString())).and()
                .body("earliestOrder.quantity", equalTo((int) order.getQuantity())).and()
                .body("lastOrder.orderId", equalTo((int) order2.getOrderId())).and()
                .body("lastOrder.orderType", equalTo(order2.getOrderType().toString())).and()
                .body("biggestOrder.orderId", equalTo((int) order.getOrderId())).and()
                .body("biggestOrder.orderType", equalTo(order.getOrderType().toString())).and()
                .body("biggestOrder.quantity", equalTo((int) order.getQuantity())).and()

                .body("smallestOrder.orderId", equalTo((int) order2.getOrderId())).and()
                .body("smallestOrder.orderType", equalTo(order2.getOrderType().toString())).and()
                .body("smallestOrder.quantity", equalTo((int) order2.getQuantity()));
    }
}
