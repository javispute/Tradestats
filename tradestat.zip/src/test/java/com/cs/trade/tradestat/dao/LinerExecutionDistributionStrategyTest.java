package com.cs.trade.tradestat.dao;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Test;

import com.cs.trade.tradestat.exception.NoNewExecutionExceptedException;
import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBook;
import com.cs.trade.tradestat.util.BeanCreationUtil;

public class LinerExecutionDistributionStrategyTest {
    private static long orderbookId = 1;
    private static long instrumentId = 1234;
    ExecutionDistributionStrategy execStrategy = new LinerExecutionDistributionStrategy();

    private void validateExecutedOrder(ExecutedOrder exOdr, boolean isValid, long qty, BigDecimal execPrice) {
        assertThat(exOdr.isValid(), equalTo(isValid));
        assertThat(exOdr.getExecutionQuantity(), equalTo(qty));
        assertThat(exOdr.getExecutionPrice(), equalTo(execPrice));
    }
    
    @Test
    public void testBookExecution_FullQuantity() {

        long qty1 = 34;
        long qty2 = 50;
        long exQty = qty1 + qty2;
        long exPrice = 50;

        Execution execution = BeanCreationUtil.createExecution(orderbookId, exQty, exPrice);
        OrderBook orderBook = getOrderBook_withTwoMarketOrder(qty1, qty2);

        execStrategy.executeOrder(orderBook, execution);

        List<ExecutedOrder> exOrders = orderBook.getExecutedOrders();

        validateExecutedOrder(exOrders.get(0), true, qty1, new BigDecimal(qty1 * exPrice));
        validateExecutedOrder(exOrders.get(1), true, qty2, new BigDecimal(qty2 * exPrice));
    }


    @Test
    public void testBookExecution_PartialQuantity() {
        
        long qty1 = 126;
        long qty2 = 54;
        long qty3 = 120;
        long qty4 = 50;
        double lpOrdr3 = 50;
        double lpOrdr4 = 40;
        long exQty = qty1 + qty2 +  qty3;
        long exPrice = 50;
        double ratio = 0.5;

        Execution execution = BeanCreationUtil.createExecution(orderbookId, (long)(exQty * ratio), exPrice);
        OrderBook orderBook = getOrderBook_withTwoMarketOrder_TwoLimitedOrder(qty1,qty2,qty3,qty4, lpOrdr3,lpOrdr4);
        execStrategy.executeOrder(orderBook, execution);
        List<ExecutedOrder> exOrders = orderBook.getExecutedOrders();
        
        validateExecutedOrder(exOrders.get(0), true, qty1 /2 , new BigDecimal( (qty1 /2 )  * exPrice));
        validateExecutedOrder(exOrders.get(1), true, qty2 /2 , new BigDecimal( (qty2 /2 )  * exPrice));
        validateExecutedOrder(exOrders.get(2), true, qty3 /2 , new BigDecimal( (qty3 /2 )  * exPrice));
        validateExecutedOrder(exOrders.get(3), false, 0 , new BigDecimal(0));

    }
    
    @Test
    public void testBookExecution_TwoTimePartialQuantity() {
        
        long qty1 = 126;
        long qty2 = 54;
        long qty3 = 120;
        long qty4 = 50;
        double lpOrdr3 = 50;
        double lpOrdr4 = 40;
        long exQty = qty1 + qty2 +  qty3;
        long exPrice = 50;
        double ratio = 0.5;
        

        Execution execution = BeanCreationUtil.createExecution(orderbookId, (long)(exQty * ratio), exPrice);
        
        OrderBook orderBook = getOrderBook_withTwoMarketOrder_TwoLimitedOrder(qty1,qty2,qty3,qty4, lpOrdr3,lpOrdr4);
        execStrategy.executeOrder(orderBook, execution);
        List<ExecutedOrder> exOrders = orderBook.getExecutedOrders();
        
        validateExecutedOrder(exOrders.get(0), true, qty1 /2 , new BigDecimal( (qty1 /2 )  * exPrice));
        validateExecutedOrder(exOrders.get(1), true, qty2 /2 , new BigDecimal( (qty2 /2 )  * exPrice));
        validateExecutedOrder(exOrders.get(2), true, qty3 /2 , new BigDecimal( (qty3 /2 )  * exPrice));
        validateExecutedOrder(exOrders.get(3), false, 0 , new BigDecimal(0));

        execStrategy.executeOrder(orderBook, execution);
        
        validateExecutedOrder(exOrders.get(0), true, qty1  , new BigDecimal( qty1   * exPrice));
        validateExecutedOrder(exOrders.get(1), true, qty2 , new BigDecimal( qty2  * exPrice));
        validateExecutedOrder(exOrders.get(2), true, qty3 , new BigDecimal( qty3  * exPrice));
        validateExecutedOrder(exOrders.get(3), false, 0 , new BigDecimal(0));
    }
    
    
    @Test
    public void testBookExecution_TwoTimePartialQuantity_SelectFloorPrice() {
        
        long qty1 = 23;
        long qty2 = 20;
        long qty3 = 56;
        long qty4 = 65;
        
        double lpOrdr3 = 50;
        double lpOrdr4 = 50;
        long exPrice = 50;
        

        Execution execution = BeanCreationUtil.createExecution(orderbookId, 47, exPrice);
        
        OrderBook orderBook = getOrderBook_withTwoMarketOrder_TwoLimitedOrder(qty1,qty2,qty3,qty4, lpOrdr3,lpOrdr4);
        execStrategy.executeOrder(orderBook, execution);
        List<ExecutedOrder> exOrders = orderBook.getExecutedOrders();
        
        validateExecutedOrder(exOrders.get(0), true, 6 , new BigDecimal( 6  * exPrice));
        validateExecutedOrder(exOrders.get(1), true, 5 , new BigDecimal( 5  * exPrice));
        validateExecutedOrder(exOrders.get(2), true, 17 , new BigDecimal( 17 * exPrice));
        validateExecutedOrder(exOrders.get(3), true, 19 , new BigDecimal(19 * exPrice));
    }
    
    @Test(expected = NoNewExecutionExceptedException.class)
    public void testBookExecution_ExecuteEvenAfterFullQuantity() {

        long qty1 = 34;
        long qty2 = 50;
        long exQty = qty1 + qty2;
        long exPrice = 50;

        Execution execution = BeanCreationUtil.createExecution(orderbookId, exQty, exPrice);
        OrderBook orderBook = getOrderBook_withTwoMarketOrder(qty1, qty2);

        execStrategy.executeOrder(orderBook, execution);

        List<ExecutedOrder> exOrders = orderBook.getExecutedOrders();

        validateExecutedOrder(exOrders.get(0), true, qty1, new BigDecimal(qty1 * exPrice));
        validateExecutedOrder(exOrders.get(1), true, qty2, new BigDecimal(qty2 * exPrice));

        execStrategy.executeOrder(orderBook, execution);

    }
    
    private OrderBook getOrderBook_withTwoMarketOrder(long qty1, long qty2) {
        OrderBook orderbook = new OrderBook(instrumentId, true);
        Order order = BeanCreationUtil.createMarketOrder(orderbook.getOrderbookId(), qty1);
        Order order1 = BeanCreationUtil.createMarketOrder(orderbook.getOrderbookId(), qty2);
        orderbook.addExecOrder(new ExecutedOrder(order));
        orderbook.addExecOrder(new ExecutedOrder(order1));

        return orderbook;
    }

    private OrderBook getOrderBook_withTwoMarketOrder_TwoLimitedOrder(long q1, long q2, long q3, long q4, double lpOrdr3, double lpOrdr4) {
        OrderBook orderbook = new OrderBook(instrumentId, true);
        Order order = BeanCreationUtil.createMarketOrder(orderbook.getOrderbookId(), q1);
        Order order1 = BeanCreationUtil.createMarketOrder(orderbook.getOrderbookId(), q2);
        Order order2 = BeanCreationUtil.createLimitPriceOrder(orderbook.getOrderbookId(), q3, lpOrdr3);
        Order order3 = BeanCreationUtil.createLimitPriceOrder(orderbook.getOrderbookId(), q4, lpOrdr4);
        orderbook.addExecOrder(new ExecutedOrder(order));
        orderbook.addExecOrder(new ExecutedOrder(order1));
        orderbook.addExecOrder(new ExecutedOrder(order2));
        orderbook.addExecOrder(new ExecutedOrder(order3));
        return orderbook;
    }

}
