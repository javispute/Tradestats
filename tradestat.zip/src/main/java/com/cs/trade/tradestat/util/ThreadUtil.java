package com.cs.trade.tradestat.util;

public class ThreadUtil {

    public static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (Exception e) {

        }
    }
}
