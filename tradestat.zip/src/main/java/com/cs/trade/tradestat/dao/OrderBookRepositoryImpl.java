package com.cs.trade.tradestat.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cs.trade.tradestat.exception.CloseBookException;
import com.cs.trade.tradestat.exception.DifferentExecutionPriceException;
import com.cs.trade.tradestat.exception.NoNewExecutionExceptedException;
import com.cs.trade.tradestat.exception.NoSuchBookExistsException;
import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBook;

@Repository
public class OrderBookRepositoryImpl implements OrderBookRepository {

    Lock lock = new ReentrantLock();
    private Map<Long, OrderBook> orderBooksByInstrument = new ConcurrentHashMap<>();
    private Map<Long, OrderBook> orderBooksById = new ConcurrentHashMap<>();
    private Map<Long, ExecutedOrder> orderMap = new ConcurrentHashMap<>();

    @Autowired
    private ExecutionDistributionStrategy executionDistributor;

    @Override
    public long openOrderBook(long instrumentId) {
        try {
            lock.lock();
            if (orderBooksByInstrument.containsKey(instrumentId) == false) {
                OrderBook orderBook = new OrderBook(instrumentId, true);
                orderBooksByInstrument.put(instrumentId, orderBook);
                orderBooksById.put(orderBook.getOrderbookId(), orderBook);
            }
            if (orderBooksByInstrument.get(instrumentId).isOpen() == false) {
                throw new CloseBookException("OrderBook is closed for instrument : " + instrumentId);
            }
        } finally {
            lock.unlock();
        }
        return orderBooksByInstrument.get(instrumentId).getOrderbookId();

    }

    @Override
    public boolean closeOrderBook(long orderBookId) {
        if (orderBooksById.containsKey(orderBookId)) {
            orderBooksById.get(orderBookId).setOpen(false);
            return orderBooksById.get(orderBookId).isOpen();
        }
        throw new NoSuchBookExistsException("No book exists for instrument : " + orderBookId);
    }

    @Override
    public boolean placeOrder(Order order) {
        OrderBook book = this.orderBooksById.get(order.getOrderbookId());
        // lock OrderBookRepository would limit no of request served in unit time.
        try {
            book.lock();
            if (book.isOpen() && book.placeOrder(order)) {
                ExecutedOrder exOrder = new ExecutedOrder(order);
                orderMap.put(order.getOrderId(), exOrder);
                book.addExecOrder(exOrder);
                return true;
            }
        } finally {
            book.unlock();
        }

        throw new CloseBookException("Order Book is closed for instrument : " + order.getOrderbookId());
    }

    @Override
    public Order getOrderById(long orderId) {
        return this.orderMap.containsKey(orderId) ? this.orderMap.get(orderId) : null;
    }

    @Override
    public List<ExecutedOrder> executeBook(Execution execution) {
        OrderBook book = orderBooksById.get(execution.getOrderbookId());
        if (book.isOpen()) {
            throw new NoNewExecutionExceptedException("Book is open, book can't be executed.");
        }
        validateExecutionPrice(book, execution);
        executionDistributor.executeOrder(book, execution);
        return book.getExecutedOrders();
    }

    private void validateExecutionPrice(OrderBook book, Execution execution) {
        BigDecimal unitPrice = book.getExecutedOrders().get(0).getUnitExecutionPrice();
        if (unitPrice != null) {
            if (unitPrice.equals(execution.getPrice()) == false) {
                throw new DifferentExecutionPriceException("Execution price expected to be " + unitPrice + " but found :" + execution.getPrice());
            }
        } else {
            for (ExecutedOrder exOdr : book.getExecutedOrders()) {
                exOdr.setUnitExecutionPrice(execution.getPrice());
            }
        }
    }

    public void setExecutionDistributor(ExecutionDistributionStrategy executionDistributor) {
        this.executionDistributor = executionDistributor;
    }

    @Override
    public OrderBook getOrderBookByInstrument(long instrumentId) {
        return this.orderBooksByInstrument.get(instrumentId);
    }
    
    @Override
    public OrderBook getOrderBookById(long orderbookId) {
        return this.orderBooksById.get(orderbookId);
    }
}
