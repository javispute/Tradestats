package com.cs.trade.tradestat.model;

public class OrderBookStatus {
    private long orderbookId;
    private boolean isOpen;

    public OrderBookStatus(long orderbookId, boolean isOpen) {
        this.orderbookId = orderbookId;
        this.isOpen = isOpen;
    }

    public boolean isOpen() {
        return isOpen;
    }

    public long getOrderbookId() {
        return orderbookId;
    }

}
