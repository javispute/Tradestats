package com.cs.trade.tradestat.model;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class OrderReq {
    private long orderbookId;
    private long quantity;
    @JsonIgnore
    private Date entryDate = new Date();
    private BigDecimal limitPrice;
    private OrderType orderType = OrderType.MARKET_ORDER;

    public void setOrderbookId(long instrumentId) {
        this.orderbookId = instrumentId;
    }

    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate == null ? new Date() : entryDate;
    }

    public void setLimitPrice(BigDecimal limitPrice) {
        this.limitPrice = limitPrice;
    }

    public void setOrderType(OrderType orderType) {
        this.orderType = orderType;
    }

    public long getOrderbookId() {
        return orderbookId;
    }

    public long getQuantity() {
        return quantity;
    }

    public Date getEntryDate() {
        return this.entryDate;
    }

    public BigDecimal getLimitPrice() {
        return limitPrice;
    }

    public OrderType getOrderType() {
        return orderType;
    }

    /*
     * This method need to be implemented for test case to work else mock bean is not able to return the order bean
     */
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof OrderReq) {
            OrderReq req = (OrderReq) obj;
            if (this.orderbookId == req.orderbookId && this.quantity == req.quantity) {
                if (this.orderType.equals(req.orderType)) {
                    if ((this.limitPrice == null && req.limitPrice == null) || (this.limitPrice != null && this.limitPrice.equals(req.limitPrice))) {
                        return true;
                    }
                }
            }

        }
        return false;
    }

}
