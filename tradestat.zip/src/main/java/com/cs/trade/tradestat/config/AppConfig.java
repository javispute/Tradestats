package com.cs.trade.tradestat.config;

import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.cs.trade.tradestat.controller.ShutdownController;
import com.cs.trade.tradestat.model.AppStatus;

@EnableWebMvc
@EnableAsync
@Configuration
@EnableAspectJAutoProxy
@ComponentScan("com.cs.trade.tradestat")
public class AppConfig implements WebMvcConfigurer {
	@Override
	public void addResourceHandlers(final ResourceHandlerRegistry registry) {
		/* for index.html */
		registry.addResourceHandler("/js/**").addResourceLocations("classpath:/resources/js/");
		registry.addResourceHandler("/index.html").addResourceLocations("classpath:/resources/");
		/* for swagger ui */
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
	}

	@Bean
	public AppStatus getAppStatus() {
		return new AppStatus();
	}

	/* required for graceful shutdown */
	@Bean
	public ConfigurableServletWebServerFactory webServerFactory(final ShutdownController gracefulShutdown) {
		TomcatServletWebServerFactory factory = new TomcatServletWebServerFactory();
		factory.addConnectorCustomizers(gracefulShutdown);
		return factory;
	}

}
