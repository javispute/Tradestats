package com.cs.trade.tradestat.exception;

public class NoNewExecutionExceptedException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public NoNewExecutionExceptedException() {

	}

	public NoNewExecutionExceptedException(Throwable th) {
		super(th);
	}

	public NoNewExecutionExceptedException(String msg) {
		super(msg);
	}
}
