package com.cs.trade.tradestat.exception;

public class DifferentExecutionPriceException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public DifferentExecutionPriceException() {

	}

	public DifferentExecutionPriceException(Throwable th) {
		super(th);
	}
	public DifferentExecutionPriceException(String msg) {
		super(msg);
	}
}
