package com.cs.trade.tradestat.aspect;

import java.time.Duration;
import java.time.LocalDateTime;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.cs.trade.tradestat.exception.SystemUnavailableException;
import com.cs.trade.tradestat.model.AppStatus;

/***
 * Various performance metrics can be calculated here such as total request and so on.
 */
@Aspect
@Component
@Order(1)
public class MetricsAspect {

    @Autowired
    AppStatus appStatus;

    private static final Logger logger = LoggerFactory.getLogger(MetricsAspect.class);

    @Pointcut("within(com.cs.trade.tradestat.service.OrderBookServiceImpl+)")
    public void businessLogicMethods() {
    }

    @Around("businessLogicMethods()")
    public Object log(ProceedingJoinPoint pjp) throws Throwable {
        logger.info(" Entry " + pjp.getSignature().getName());
        if (this.appStatus.isShutDownRequested()) {
            throw new SystemUnavailableException("System is temporarily unavailable, please try after some time.");
        }
        Object retVal = null;
        LocalDateTime startTime = LocalDateTime.now();
        try {
            this.appStatus.addMethodRunning(pjp.getSignature().getName());
            retVal = pjp.proceed();
        } finally {
            this.appStatus.removeMethodRunning(pjp.getSignature().getName());
            LocalDateTime endTime = LocalDateTime.now();
            Duration duration = Duration.between(startTime, endTime);
            logger.info(" Exit " + pjp.getSignature().getName() + " completed in : " + duration.toMillis() + "ms");
        }
        return retVal;
    }
}
