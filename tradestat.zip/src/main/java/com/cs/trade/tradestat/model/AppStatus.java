package com.cs.trade.tradestat.model;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppStatus {
    private static final Logger logger = LoggerFactory.getLogger(AppStatus.class);
    private volatile Map<String, AtomicInteger> methodCallCountMap = new ConcurrentHashMap<>();
    private volatile boolean isShutDownRequested = false;

    public int addMethodRunning(String method) {
        if (this.methodCallCountMap.containsKey(method) == false) {
            this.methodCallCountMap.put(method, new AtomicInteger(0));
        }
        AtomicInteger cnt = this.methodCallCountMap.get(method);
        return cnt.incrementAndGet();
    }

    public int removeMethodRunning(String method) {
        AtomicInteger cnt = this.methodCallCountMap.get(method);
        if (cnt != null) {
            if (cnt.decrementAndGet() == 0) {
                this.methodCallCountMap.remove(method);
            }
        }
        return 0;
    }

    /* for debugging purpose */
    public void displayRunningMethods() {
        logger.trace("Currently Running Methods : " + this.methodCallCountMap);
    }

    public boolean isAnyMethodRunning() {
        return this.methodCallCountMap.isEmpty() == false;
    }

    public boolean isShutDownRequested() {
        return isShutDownRequested;
    }

    public void setShutDownRequested(boolean isShutDownRequested) {
        this.isShutDownRequested = isShutDownRequested;
    }

}
