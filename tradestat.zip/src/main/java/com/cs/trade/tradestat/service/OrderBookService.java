package com.cs.trade.tradestat.service;

import java.util.List;

import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderReq;

public interface OrderBookService {
    public long openOrderBook(long instrumentId);

    public boolean closeOrderBook(long orderbookId);

    public Order placeOrder(OrderReq order);

    public Order getOrderById(long orderId);

    public List<ExecutedOrder> executeBook(Execution execution);
}
