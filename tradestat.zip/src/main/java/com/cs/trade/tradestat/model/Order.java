package com.cs.trade.tradestat.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;

import com.cs.trade.tradestat.util.JsonUtil;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class Order {
    @JsonIgnore
    private static AtomicLong orderIdGenerator = new AtomicLong(1);

    private long orderId;
    private long orderbookId;
    private long quantity;
    @JsonIgnore
    private Date entryDate;
    private BigDecimal limitPrice;
    private OrderType orderType;

    public static Order getInstance(long orderbookId, long quantity, Date entryDate, BigDecimal limitPrice, OrderType orderType) {
        long orderId = orderIdGenerator.getAndIncrement();
        return new Order(orderId, orderbookId, quantity, entryDate, limitPrice, orderType);
    }

    public static Order getInstance(long orderbookId, long quantity, Date entryDate) {
        long orderId = orderIdGenerator.getAndIncrement();
        return new Order(orderId, orderbookId, quantity, entryDate);
    }

    private Order(long orderId, long orderbookId, long quantity, Date entryDate, BigDecimal limitPrice, OrderType orderType) {
        this.orderId = orderId;
        this.orderbookId = orderbookId;
        this.quantity = quantity;
        this.entryDate = new Date(entryDate.getTime());
        this.limitPrice = limitPrice;
        this.orderType = orderType;
    }

    protected Order(Order order) {
        this.orderId = order.orderId;
        this.orderbookId = order.orderbookId;
        this.limitPrice = order.limitPrice;
        this.entryDate = order.entryDate;
        this.orderType = order.orderType;
        this.quantity = order.quantity;
    }

    public static Order getInstance(OrderReq oreq) {
        long orderId = orderIdGenerator.getAndIncrement();
        OrderType otype = oreq.getLimitPrice() != null && BigDecimal.ZERO.compareTo(oreq.getLimitPrice()) == -1 ? OrderType.LIMIT_ORDER
                : OrderType.MARKET_ORDER;
        return new Order(orderId, oreq.getOrderbookId(), oreq.getQuantity(), oreq.getEntryDate(), oreq.getLimitPrice(), otype);
    }

    private Order(long orderId, long orderbookId, long quantity, Date entryDate) {
        this.orderId = orderId;
        this.orderbookId = orderbookId;
        this.quantity = quantity;
        this.entryDate = entryDate;
        this.orderType = OrderType.MARKET_ORDER;
    }

    public long getOrderId() {
        return orderId;
    }

    public long getOrderbookId() {
        return orderbookId;
    }

    public long getQuantity() {
        return quantity;
    }

    public Date getEntryDate() {
        return new Date(this.entryDate.getTime());
    }

    public BigDecimal getLimitPrice() {
        return limitPrice;
    }

    public OrderType getOrderType() {
        return orderType;
    }

    public String toString() {
        return JsonUtil.toJsonString(this);
    }

}
