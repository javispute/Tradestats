package com.cs.trade.tradestat.model;

public enum OrderType {
     LIMIT_ORDER, MARKET_ORDER
}
