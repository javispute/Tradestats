package com.cs.trade.tradestat.model;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Component
public class OrderStats {
	private AtomicLong totalOrderCount = new AtomicLong(0);
	private AtomicLong totalDemand = new AtomicLong(0);
	private Order biggestOrder;
	private Order smallestOrder;
	@JsonIgnore
	private long biggestQuantity = 0;
	@JsonIgnore
	private long smallestQuantity = Long.MAX_VALUE;
	private Order earliestOrder;
	private Order lastOrder;
	private Map<BigDecimal, AtomicLong> limitPriceDemandMap = new ConcurrentHashMap<>();

	public void updateStats(Order order) {

		synchronized (this) {
			if (earliestOrder == null) {
				earliestOrder = order;
			}
		}
		lastOrder = order;
		totalOrderCount.incrementAndGet();
		totalDemand.addAndGet(order.getQuantity());
		if (order.getQuantity() > biggestQuantity) {
			this.biggestQuantity = order.getQuantity();
			this.biggestOrder = order;
		}
		if (order.getQuantity() < this.smallestQuantity) {
			this.smallestQuantity = order.getQuantity();
			this.smallestOrder = order;
		}
		if (order.getOrderType().equals(OrderType.LIMIT_ORDER)) {
			if (this.limitPriceDemandMap.containsKey(order.getLimitPrice())) {
				AtomicLong demand = this.limitPriceDemandMap.get(order.getLimitPrice());
				demand.addAndGet(order.getQuantity());

			} else {
				this.limitPriceDemandMap.put(order.getLimitPrice(), new AtomicLong(order.getQuantity()));
			}
		}
	}

	public AtomicLong getTotalOrderCount() {
		return totalOrderCount;
	}

	public AtomicLong getTotalDemand() {
		return totalDemand;
	}

	public Order getBiggestOrder() {
		return biggestOrder;
	}

	public Order getSmallestOrder() {
		return smallestOrder;
	}

	public Order getEarliestOrder() {
		return earliestOrder;
	}

	public Order getLastOrder() {
		return lastOrder;
	}

	public Map<BigDecimal, AtomicLong> getLimitPriceDemandMap() {
		return limitPriceDemandMap;
	}

	/*
	 * 
	 * obtain statistics about the amount of orders in each book, demand, the
	 * biggest order and the smallest order, the earliest order entry, the last
	 * order entry, limit break down (a table with limit prices and demand per
	 * limit price). Demand = accumulated order quantity. 3.
	 */
}
