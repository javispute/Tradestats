package com.cs.trade.tradestat.model;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class OrderBookStats {
    private Map<Long, OrderStats> bookIdNOrderStatsMap = new ConcurrentHashMap<>();
    private Map<Long, ExecutionStats> bookNExecStatsMap = new ConcurrentHashMap<>();
    private static final Logger logger = LoggerFactory.getLogger(OrderBookStats.class);

    public void updateOrderStats(long orderbookId, Order order) {
        logger.debug("update stats for  Instrument Id : {} , Order : {}", orderbookId, order);
        OrderStats stats = this.bookIdNOrderStatsMap.get(orderbookId);
        if (stats == null) {
            logger.debug(" Order Stats created for Instrument Id : " + orderbookId);
            stats = new OrderStats();
            this.bookIdNOrderStatsMap.put(orderbookId, stats);
        }
        stats.updateStats(order);
    }

    public void updateExecStats(long orderbookId, List<ExecutedOrder> execOrders) {

        logger.debug("update execution stats for  Instrument Id : {}, orders : {} ", orderbookId, execOrders);
        ExecutionStats stats = this.bookNExecStatsMap.get(orderbookId);
        if (stats == null) {
            logger.debug(" Execution Stats created for Instrument Id : " + orderbookId);
            stats = new ExecutionStats();
            this.bookNExecStatsMap.put(orderbookId, stats);
        }
        stats.updateExecStats(execOrders);
    }

    public OrderStats getOrderStats(long orderbookId) {
        return this.bookIdNOrderStatsMap.get(orderbookId);
    }

    public ExecutionStats getOrderExecStats(long orderbookId) {
        return this.bookNExecStatsMap.get(orderbookId);
    }
}
