package com.cs.trade.tradestat.exception;

public class NoOrderFoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public NoOrderFoundException() {

	}

	public NoOrderFoundException(Throwable th) {
		super(th);
	}
	public NoOrderFoundException(String msg) {
		super(msg);
	}
}
