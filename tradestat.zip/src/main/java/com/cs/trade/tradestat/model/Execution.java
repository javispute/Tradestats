package com.cs.trade.tradestat.model;

import java.math.BigDecimal;

import com.cs.trade.tradestat.util.JsonUtil;

public class Execution {

    private long orderbookId;
    private BigDecimal price;
    private long quantity;

    public void setOrderbookId(long instrumentId) {
        this.orderbookId = instrumentId;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }

    public long getOrderbookId() {
        return orderbookId;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public long getQuantity() {
        return quantity;
    }

    public String toString() {
        return JsonUtil.toJsonString(this);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Execution) {
            Execution exe = (Execution) obj;
            if (this.orderbookId == exe.orderbookId && this.quantity == exe.quantity) {
                if (this.price != null && this.price.equals(exe.price)) {
                    return true;
                }
            }
        }
        return false;
    }

}
