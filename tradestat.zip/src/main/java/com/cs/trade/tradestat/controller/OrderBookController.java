package com.cs.trade.tradestat.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cs.trade.tradestat.exception.NoNewExecutionExceptedException;
import com.cs.trade.tradestat.exception.NoSuchBookExistsException;
import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.ExecutionStats;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBookStats;
import com.cs.trade.tradestat.model.OrderBookStatus;
import com.cs.trade.tradestat.model.OrderReq;
import com.cs.trade.tradestat.model.OrderStats;
import com.cs.trade.tradestat.service.OrderBookService;

@RestController
@RequestMapping("/orderbook")
public class OrderBookController {

    @Autowired
    OrderBookService orderBookService;

    @Autowired
    OrderBookStats orderBookStats;

    @PostMapping("/{instrumentId}")
    @ResponseStatus(HttpStatus.CREATED)
    public OrderBookStatus openOrderBook(@PathVariable long instrumentId) {
        long orderbookId = orderBookService.openOrderBook(instrumentId);
        return new OrderBookStatus(orderbookId, true);
    }

    @PutMapping("/{orderbookId}")
    @ResponseStatus(HttpStatus.OK)
    public OrderBookStatus closeOrderBook(@PathVariable long orderbookId) {
        boolean status = orderBookService.closeOrderBook(orderbookId);
        return new OrderBookStatus(orderbookId, status);
    }

    @PostMapping("/{orderbookId}/order")
    @ResponseStatus(HttpStatus.CREATED)
    public Order placeOrder(@PathVariable long orderbookId, @RequestBody OrderReq order) {
        return orderBookService.placeOrder(orderbookId, order);
    }

    @GetMapping("/order/{orderId}")
    @ResponseStatus(HttpStatus.OK)
    public Order getOrderById(@PathVariable long orderId) {
        return this.orderBookService.getOrderById(orderId);
    }

    @PostMapping("/{orderbookId}/exec")
    @ResponseStatus(HttpStatus.OK)
    public List<ExecutedOrder> executeOrder(@PathVariable long orderbookId, @RequestBody Execution execution) {
        return this.orderBookService.executeBook(orderbookId,execution);
    }

    @GetMapping("/{orderbookId}/orderstats")
    @ResponseStatus(HttpStatus.OK)
    public OrderStats getOrderStats(@PathVariable long orderbookId) {
        OrderStats stats = orderBookStats.getOrderStats(orderbookId);
        if (stats == null) {
            if (this.orderBookService.isBookExists(orderbookId)) {
                throw new NoSuchBookExistsException("No order is booked on orderbook Id :" + orderbookId);
            }
            throw new NoSuchBookExistsException("No orderbook exists for orderbook Id :" + orderbookId);
        }
        return stats;
    }

    @GetMapping("/{orderbookId}/execstats")
    @ResponseStatus(HttpStatus.OK)
    public ExecutionStats getOrderExecStats(@PathVariable long orderbookId) {
        ExecutionStats stats = orderBookStats.getOrderExecStats(orderbookId);
        if (stats == null) {
            if (this.orderBookService.isBookOpen(orderbookId)) {
                throw new NoNewExecutionExceptedException("Book is open, No execution added yet for orderbookId :" + orderbookId);
            }
            throw new NoNewExecutionExceptedException("No execution added yet for orderbookId :"+orderbookId);
        }
        return stats;
    }
}
