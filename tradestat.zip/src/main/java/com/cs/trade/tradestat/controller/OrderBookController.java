package com.cs.trade.tradestat.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.ExecutionStats;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBookStats;
import com.cs.trade.tradestat.model.OrderBookStatus;
import com.cs.trade.tradestat.model.OrderReq;
import com.cs.trade.tradestat.model.OrderStats;
import com.cs.trade.tradestat.service.OrderBookService;

@Controller
@RequestMapping("/orderbook")
public class OrderBookController {

    @Autowired
    OrderBookService orderBookService;

    @Autowired
    OrderBookStats orderBookStats;

    @PostMapping("/{instrumentId}")
    @ResponseBody
    public OrderBookStatus openOrderBook(@PathVariable long instrumentId) {
        long orderbookId = orderBookService.openOrderBook(instrumentId);
        return new OrderBookStatus(orderbookId, true);
    }

    @PutMapping("/{orderbookId}")
    @ResponseBody
    public OrderBookStatus closeOrderBook(@PathVariable long orderbookId) {
        boolean status = orderBookService.closeOrderBook(orderbookId);
        return new OrderBookStatus(orderbookId, status);
    }

    @PostMapping("/order")
    @ResponseBody
    public Order placeOrder(@RequestBody OrderReq order) {
        return orderBookService.placeOrder(order);
    }

    @GetMapping("/order/{orderId}")
    @ResponseBody
    public Order getOrderById(@PathVariable long orderId) {
        return this.orderBookService.getOrderById(orderId);
    }

    @PostMapping("/exec")
    @ResponseBody
    public List<ExecutedOrder> executeOrder(@RequestBody Execution execution) {
        return this.orderBookService.executeBook(execution);
    }

    @GetMapping("/{orderbookId}/orderstats")
    @ResponseBody
    public OrderStats getOrderStats(@PathVariable long orderbookId) {
        return orderBookStats.getOrderStats(orderbookId);
    }

    @GetMapping("/{orderbookId}/execstats")
    @ResponseBody
    public ExecutionStats getOrderExecStats(@PathVariable long orderbookId) {
        return orderBookStats.getOrderExecStats(orderbookId);
    }
}
