package com.cs.trade.tradestat.exception;

public class SystemUnavailableException extends RuntimeException  {
	private static final long serialVersionUID = 1L;

	public SystemUnavailableException() {

	}

	public SystemUnavailableException(Throwable th) {
		super(th);
	}

	public SystemUnavailableException(String msg) {
		super(msg);
	}

}
