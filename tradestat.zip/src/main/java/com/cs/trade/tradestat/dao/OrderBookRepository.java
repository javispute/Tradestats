package com.cs.trade.tradestat.dao;

import java.util.List;

import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBook;

public interface OrderBookRepository {

    long openOrderBook(long instrumentId);

    boolean closeOrderBook(long instrumentId);

    boolean placeOrder(Order order);

    Order getOrderById(long orderId);

    List<ExecutedOrder> executeBook(Execution execution);

    OrderBook getOrderBookByInstrument(long instrumentId);

    OrderBook getOrderBookById(long orderbookId);

}