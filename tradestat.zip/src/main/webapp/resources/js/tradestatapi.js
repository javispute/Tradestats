var baseUrl="http://localhost:8080/tradestat"
var instrumentOrderBookIdArr = new Array(); 
var tableconfig =  {
        // General Style for Table
        borderWidth: '1px',
        borderStyle: 'solid',
        borderColor: '#ccc',
        fontFamily: 'Verdana, Helvetica, Arial, FreeSans, sans-serif',
        
        // Table Header Style
        thBg: '#F3F3F3',
        thColor: '#0E0E0E',
        thHeight: '30px',
        thFontFamily: '"Open Sans Condensed", sans-serif',
        thFontSize: '14px',
        thTextTransform: 'capitalize',
        
        // Table Body/Row Style
        trBg: '#FFFFFF',
        trColor: '#0E0E0E',
        trHeight: '25px',
        trFontFamily: '"Open Sans", sans-serif',
        trFontSize: '13px',
        
        // Table Body's Column Style
        tdPaddingLeft: '10px',
        tdPaddingRight: '10px'
    };

$(document).ready(function(){
	
	$('ul.tabs li').click(function(){
		var tab_id = $(this).attr('data-tab');

		$('ul.tabs li').removeClass('current');
		$('.tab-content').removeClass('current');

		$(this).addClass('current');
		$("#"+tab_id).addClass('current');
	});	
	
	
	$('#openBtn').click(function(){
		var instId = $("#opinstId").val();
		if(instId == "") {
			$('#openMsg').text("please enter instrumentId ");
			$("#opinstId").focus();
			return;
		}
		$.ajax({
	        url: baseUrl+"/orderbook/"+ instId, 
	        method: "POST" ,
	        accept:"application/json;charset=UTF-8",
	        contentType:"application/json;charset=utf-8",
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw==", "Accept-Encoding" : "None" },
	        dataType: 'json',
	        success: function(result) {
	        	$('#openMsg').text("instrument : " + $("#opinstId").val() + " orderbook id : " + result.orderbookId +" open : " +result.open);
	        },
	        error: function(result) {
	           $('#openMsg').text(result.responseJSON.message);
	        }
		 });
	});
	
	$('#closeBtn').click(function(){
		var instId = $("#closeOBId").val();
		if(instId == "") {
			$('#closeMsg').text("please enter orderbook id ");
			$("#closeOBId").focus();
			return;
		}
		$.ajax({
	        url: baseUrl+"/orderbook/"+ instId, 
	        method: "PUT" ,
	        accept:"application/json;charset=UTF-8",
	        contentType:"application/json;charset=utf-8",
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw==", "Accept-Encoding" : "None" },
	        dataType: 'json',
	        success: function(result) {
	        	$('#closeMsg').text( " orderbook id : " + result.orderbookId +" open : " +result.open);
	        },
	        error: function(result) {
	           $('#closeMsg').text(result.responseJSON.message);
	        }
		 });
	});
	
	
	/*-------   Order Tab --------------------*/
	
	$('#placeOrderBtn').click(function(){
		
		
		var order = new Object();
		order.orderbookId=$('#poInstId').val();
		
		var lp = $.trim( $('#polimitPrice').val() );
		 order.orderType = "MARKET_ORDER";
		if(lp!=""){
			order.orderType="LIMIT_ORDER";
			order.limitPrice=lp;
		} 
		order.quantity=$('#poqty').val();
		
			
		$.ajax({
	        url: baseUrl+"/orderbook/order",
	        method: "POST",
	        data: JSON.stringify(order),
	        accept:"application/json;charset=UTF-8",
	        contentType:"application/json;charset=utf-8",
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw==", "Accept-Encoding" : "None" },
	        dataType: 'json',
	        success: function ( result) {
	        	var arr = new Array();
	        	arr[0]=result;
	        	$('#poMsg').createTable(arr,tableconfig);
	        },
	        error: function(result) {
	        	var arr = new Array();
	        	arr[0]=result.responseJSON;
	        	$('#poMsg').createTable(arr,tableconfig);
	        }
		 });
	});
	
	$('#orderByIdBtn').click(function(){
		$.ajax({
	        url: baseUrl+"/orderbook/order/"+$("#OdrByOId").val() ,
	        method: "GET",
	        dataType: 'json',
	        accept:"application/json;charset=UTF-8",
	        contentType:"application/json;charset=utf-8",
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw==", "Accept-Encoding" : "None" },
	        success: function(result) {
	        	if(result == "") {
	        		$('#odrByIdMsg').text("Order does not exists for id :" +$("#OdrByOId").val());
	        	} else {
	        		var arr = new Array();
		        	arr[0]=result;
	        		$('#odrByIdMsg').createTable(arr,tableconfig);
	        	}
	        },
	        error: function(result) {
	        	var arr = new Array();
	        	arr[0]=result.responseJSON;
        		$('#odrByIdMsg').createTable(arr,tableconfig);
	           
	        }
		 });
	});
	

   /*-------   Execution Tab --------------------*/
   $('#execBtn').click(function(){
		var exec = new Object();
		exec.orderbookId=$('#execInstId').val();
		exec.quantity=$('#execqty').val();
		exec.price=$('#execPrice').val();
		
		$.ajax({
	        url: baseUrl+"/orderbook/exec",
	        method: "POST",
	        data:JSON.stringify(exec),
	        accept:"application/json;charset=UTF-8",
	        contentType:"application/json;charset=utf-8",
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw==", "Accept-Encoding" : "None" },
	        dataType: 'json',
	        success: function ( result) {
	        	
	        	$('#execMsg').createTable(result,tableconfig);
	        },
	        error: function(result) {
	        	var arr = new Array();
	        	arr[0]=result.responseJSON;
	           $('#execMsg').createTable(arr,tableconfig);
	        }
		 });
	});
   
   /*----------------------stats -----------------------------*/
   
    $('#statsBtn').click(function(){
    	$.ajax({
	        url: baseUrl+"/orderbook/"+$("#statsInstId").val() +"/"+$("input[name='stats']:checked").val(),
	        method: "GET",
	        accept:"application/json;charset=UTF-8",
	        contentType:"application/json;charset=utf-8",
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw==", "Accept-Encoding" : "None" },
	        dataType: 'json',
	        success: function(result) {
	        	$('#statsMsg').html("<pre>"+JSON.stringify(result,null, '\t')+"</pre>");
	        },
	        error: function(result) {
	           $('#statsMsg').text(result.responseJSON.message);
	        }
		 });
    });
	
});



