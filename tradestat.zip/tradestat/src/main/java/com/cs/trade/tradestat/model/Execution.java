package com.cs.trade.tradestat.model;

import java.math.BigDecimal;

import com.cs.trade.tradestat.util.JsonUtil;

public class Execution {

	private long instrumentId;
	private BigDecimal price;
	private long quantity;

	public void setInstrumentId(long instrumentId) {
		this.instrumentId = instrumentId;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public long getInstrumentId() {
		return instrumentId;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public long getQuantity() {
		return quantity;
	}

	public String toString() {
		return JsonUtil.toJsonString(this);
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj instanceof Execution) {
			Execution exe = (Execution) obj;
           if(this.instrumentId==exe.instrumentId && this.quantity==exe.quantity) {
        	 if(this.price !=null && this.price.equals(exe.price)) {
        		 return true;
        	 }
           }
		}
		return false;
	}

}
