package com.cs.trade.tradestat.model;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class OrderBookStats {
	private Map<Long, OrderStats> instrumentOrderStatsMap = new ConcurrentHashMap<>();
	private Map<Long, ExecutionStats> instrumentExecStatsMap = new ConcurrentHashMap<>();
	private static final Logger logger = LoggerFactory.getLogger(OrderBookStats.class);

	public void updateOrderStats(long instrumentId, Order order) {
		logger.debug("update stats for  Instrument Id : {} , Order : {}", instrumentId ,order);
		OrderStats stats = this.instrumentOrderStatsMap.get(instrumentId);
		if (stats == null) {
			logger.info(" Order Stats created for Instrument Id : " + instrumentId );	
			stats = new OrderStats();
			this.instrumentOrderStatsMap.put(instrumentId, stats);
		}
		stats.updateStats(order);
	}

	public void updateExecStats(long instrumentId, List<ExecutedOrder> execOrders) {
		
		logger.debug("update execution stats for  Instrument Id : {}, orders : {} " , instrumentId , execOrders);
		ExecutionStats stats = this.instrumentExecStatsMap.get(instrumentId);
		if (stats == null) {
			logger.info(" Execution Stats created for Instrument Id : " + instrumentId );	
			stats = new ExecutionStats();
			this.instrumentExecStatsMap.put(instrumentId, stats);
		}
		stats.updateExecStats(execOrders);
	}

	public OrderStats getOrderStats(long instrumentId) {
		return this.instrumentOrderStatsMap.get(instrumentId);
	}

	public ExecutionStats getOrderExecStats(long instrumentId) {
		return this.instrumentExecStatsMap.get(instrumentId);
	}
}
