package com.cs.trade.tradestat.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cs.trade.tradestat.dao.OrderBookRepository;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBook;
import com.cs.trade.tradestat.model.OrderBookStats;

@Aspect
@Component
public class OrderAspect {

	private static final Logger logger = LoggerFactory.getLogger(OrderAspect.class);
	@Autowired
	private OrderBookStats orderBookStats;

	@Around("execution(* com.cs.trade.tradestat.dao.OrderBookRepository.placeOrder(*))")
	public Object collectOrderStats(ProceedingJoinPoint pjp) throws Throwable {

		Object retVal = pjp.proceed();
		try {
			boolean isOrderPlaced = (boolean) retVal;
			if (isOrderPlaced) {
				Order order = (Order) pjp.getArgs()[0];
				logger.info("Order placed : {} ", order);
				orderBookStats.updateOrderStats(order.getInstrumentId(), order);
			}
		} catch (ClassCastException e) {

		}
		return retVal;
	}

	@Around("execution(* com.cs.trade.tradestat.dao.OrderBookRepository.executeBook(*))")
	public Object collectExecStats(ProceedingJoinPoint pjp) throws Throwable {

		Object retVal = pjp.proceed();
		try {
			Execution exec = (Execution) pjp.getArgs()[0];
			logger.info("Execution placed : {}" , exec);
			OrderBook book = ((OrderBookRepository)pjp.getTarget()).getOrderBook(exec.getInstrumentId());
			orderBookStats.updateExecStats(book.getInstrumentId(), book.getExecutedOrders());
		} catch (ClassCastException e) {

		}
		return retVal;
	}

}
