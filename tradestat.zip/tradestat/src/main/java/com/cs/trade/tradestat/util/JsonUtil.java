package com.cs.trade.tradestat.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {
	private static ObjectMapper mapper = new ObjectMapper();

	public static String toJsonString(Object object) {
		if (object != null) {
			try {
				return mapper.writeValueAsString(object);
			} catch (JsonProcessingException e) {
			}
			return object.toString();
		}
		return null;
	}
}
