package com.cs.trade.tradestat.exception;

public class CloseBookException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public CloseBookException() {

	}

	public CloseBookException(Throwable th) {
		super(th);
	}
	public CloseBookException(String msg) {
		super(msg);
	}
}
