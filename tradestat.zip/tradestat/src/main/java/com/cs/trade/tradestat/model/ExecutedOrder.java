package com.cs.trade.tradestat.model;

import java.math.BigDecimal;
import java.util.Date;

import com.cs.trade.tradestat.util.JsonUtil;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class ExecutedOrder {
	@JsonIgnore
	private Order order;
	private long orderId;
	private long instrumentId;
	private long quantity;
	@JsonIgnore
	private Date entryDate;
	private BigDecimal limitPrice;
	private BigDecimal unitExecutionPrice;
	

	private OrderType orderType;
	private boolean isValid;
	@JsonIgnore
	private double distributionRatio;
	private long executionQuantity;
	private BigDecimal executionPrice=new BigDecimal(0);
	@JsonIgnore
	private StatisticalQuantity statsCounts;

	public ExecutedOrder(Order order) {
		this.order = order;
		this.orderId = order.getOrderId();
		this.instrumentId = order.getInstrumentId();
		this.quantity = order.getQuantity();
		this.entryDate = order.getEntryDate();
		this.limitPrice = order.getLimitPrice();
		this.orderType = order.getOrderType();
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}

	public void setExecutionQuantity(long execQuantity) {
		this.executionQuantity = execQuantity;
	}

	public void setExecutionPrice(BigDecimal execPrice) {
		this.executionPrice = execPrice;
	}

	public double getDistributionRatio() {
		return distributionRatio;
	}

	public void setDistributionRatio(double distributionRatio) {
		this.distributionRatio = distributionRatio;
	}

	public long getOrderId() {
		return orderId;
	}

	public long getInstrumentId() {
		return instrumentId;
	}

	public long getQuantity() {
		return quantity;
	}

	public Date getEntryDate() {
		return entryDate;
	}

	public BigDecimal getLimitPrice() {
		return limitPrice;
	}

	public OrderType getOrderType() {
		return orderType;
	}

	public boolean isValid() {
		return isValid;
	}

	public long getExecutionQuantity() {
		return executionQuantity;
	}

	public BigDecimal getExecutionPrice() {
		return executionPrice;
	}

	public StatisticalQuantity getStatsCounts() {
		return statsCounts;
	}

	public void setStatsCounts(StatisticalQuantity statsCounts) {
		this.statsCounts = statsCounts;
	}

	public Order getOrder() {
		return this.order;
	}

	public String toString() {
		return JsonUtil.toJsonString(this);
	}
	public BigDecimal getUnitExecutionPrice() {
		return unitExecutionPrice;
	}

	public void setUnitExecutionPrice(BigDecimal executionUnitPrice) {
		this.unitExecutionPrice = executionUnitPrice;
	}
}
