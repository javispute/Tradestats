package com.cs.trade.tradestat.dao;

import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.OrderBook;

public interface ExecutionDistributionStrategy {
      public boolean executeOrder(OrderBook orderBook, Execution execution);
}
