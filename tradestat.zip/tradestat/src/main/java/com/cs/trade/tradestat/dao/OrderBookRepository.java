package com.cs.trade.tradestat.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cs.trade.tradestat.exception.CloseBookException;
import com.cs.trade.tradestat.exception.DifferentExecutionPriceException;
import com.cs.trade.tradestat.exception.NoNewExecutionExceptedException;
import com.cs.trade.tradestat.exception.NoSuchBookExistsException;
import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBook;

@Repository
public class OrderBookRepository {

	private Map<Long, OrderBook> orderBooks = new ConcurrentHashMap<>();
	private Map<Long, ExecutedOrder> orderMap = new ConcurrentHashMap<>();

	@Autowired
	private ExecutionDistributionStrategy executionDistributor;

	public boolean openBook(long instrumentId, boolean isOpen) {
		if (isOpen && orderBooks.containsKey(instrumentId) == false) {
			orderBooks.put(instrumentId, new OrderBook(instrumentId));
		}
		if(orderBooks.containsKey(instrumentId)) {
			OrderBook book = orderBooks.get(instrumentId);
			book.setOpen(isOpen);
			return book.isOpen();	
		}
		throw new NoSuchBookExistsException("No Such book exists : " + instrumentId);
	}

	public boolean isOrderBookOpen(long instrumentId) {
		if (orderBooks.containsKey(instrumentId)) {
			return orderBooks.get(instrumentId).isOpen();
		}
		throw new NoSuchBookExistsException("No Order book exists for instrumentId :" + instrumentId);
	}

	public boolean placeOrder(Order order) {
		OrderBook book = this.orderBooks.get(order.getInstrumentId());
		if (book == null) {
			throw new NoSuchBookExistsException("No book exists for instrument :" + order.getInstrumentId());
		}
		if (book.isOpen()) {
			if (book.placeOrder(order)) {
				ExecutedOrder exOrder = new ExecutedOrder(order);
				orderMap.put(order.getOrderId(), exOrder);
				book.addExecOrder(exOrder);
				return true;
			}
		}
		throw new CloseBookException("Order Book is closed for instrument : " + order.getInstrumentId());
	}

	public Order getOrderById(long orderId) {
		return this.orderMap.containsKey(orderId) ? this.orderMap.get(orderId).getOrder() : null;
	}

	public ExecutedOrder getExecOrderById(long orderId) {
		return this.orderMap.get(orderId);
	}

	public List<Order> getOrders(long instrumentId) {
		if (this.orderBooks.containsKey(instrumentId)) {
			return this.orderBooks.get(instrumentId).getOrders();
		}
		return null;
	}

	public List<ExecutedOrder> executeBook(Execution execution) {
		OrderBook book = orderBooks.get(execution.getInstrumentId());
		if (book.isOpen()) {
			throw new NoNewExecutionExceptedException("Book is open, book can't be executed.");
		}
		validateExecutionPrice(book,execution);
		executionDistributor.executeOrder(book, execution);
		return book.getExecutedOrders();
	}
	private void validateExecutionPrice(OrderBook book , Execution execution) {
		BigDecimal unitPrice = book.getExecutedOrders().get(0).getUnitExecutionPrice() ;
		if(unitPrice!= null) {
		   if(unitPrice.equals(execution.getPrice())==false) {
			   throw new DifferentExecutionPriceException("Execution price expected to be " +unitPrice + " but found :" + execution.getPrice());
		   }
		} else {
		   for(ExecutedOrder exOdr: book.getExecutedOrders()) {
			    exOdr.setUnitExecutionPrice(execution.getPrice());
		   }
		}
	}

	public void setExecutionDistributor(ExecutionDistributionStrategy executionDistributor) {
		this.executionDistributor = executionDistributor;
	}

	public List<ExecutedOrder> getExecutedOrders(long instrumentId) {
		if (this.orderBooks.containsKey(instrumentId)) {
			return this.orderBooks.get(instrumentId).getExecutedOrders();
		}
		return null;
	}

	public OrderBook getOrderBook(long instrumentId) {
		return this.orderBooks.get(instrumentId);
	}
}
