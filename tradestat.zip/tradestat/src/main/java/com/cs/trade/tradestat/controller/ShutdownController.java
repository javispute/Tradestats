package com.cs.trade.tradestat.controller;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.catalina.connector.Connector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationListener;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cs.trade.tradestat.model.AppStatus;
import com.cs.trade.tradestat.util.ThreadUtil;

@RestController
public class ShutdownController
		implements ApplicationContextAware, TomcatConnectorCustomizer, ApplicationListener<ContextClosedEvent> {

	private static final Logger logger = LoggerFactory.getLogger(ShutdownController.class);
	private ApplicationContext context;
	@Autowired
	private AppStatus appStatus;
	private static final int TIMEOUT = 20;

	private volatile Connector connector;

	@Override
	public void customize(Connector connector) {
		this.connector = connector;
	}

	@PostMapping("/shutdown")
	public void shutdownContext() {
		appStatus.setShutDownRequested(true);
		while (appStatus.isAnyMethodRunning()) {
			logger.warn(" waiting to stop currently running methods ");
			appStatus.displayRunningMethods();
			ThreadUtil.sleep(10);
		}
		this.connector.pause();
		Executor executor = this.connector.getProtocolHandler().getExecutor();
		if (executor instanceof ThreadPoolExecutor) {
			try {
				ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) executor;
				threadPoolExecutor.shutdown();
				if (!threadPoolExecutor.awaitTermination(TIMEOUT, TimeUnit.SECONDS)) {
					logger.warn("Tomcat thread pool did not shut down gracefully within " + TIMEOUT
							+ " seconds. Proceeding with forceful shutdown");

					threadPoolExecutor.shutdownNow();

					if (!threadPoolExecutor.awaitTermination(TIMEOUT, TimeUnit.SECONDS)) {
						logger.error("Tomcat thread pool did not terminate");
					}
				}
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		}
		((ConfigurableApplicationContext) context).close();
	}

	@Override
	public void setApplicationContext(ApplicationContext ctx) throws BeansException {
		this.context = ctx;
	}

	@Override
	public void onApplicationEvent(ContextClosedEvent arg0) {
		shutdownContext();
	}

}