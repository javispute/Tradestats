package com.cs.trade.tradestat.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;

import com.cs.trade.tradestat.util.JsonUtil;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class Order {
	@JsonIgnore
	private static AtomicLong orderIdGenerator = new AtomicLong(1);

	private long orderId;
	private long instrumentId;
	private long quantity;
	private Date entryDate;
	private BigDecimal limitPrice;
	private OrderType orderType;

	public static Order getInstance(long instrumentId, long quantity, Date entryDate, BigDecimal limitPrice,
			OrderType orderType) {
		long orderId = orderIdGenerator.getAndIncrement();
		return new Order(orderId, instrumentId, quantity, entryDate, limitPrice, orderType);
	}

	public static Order getInstance(long instrumentId, long quantity, Date entryDate) {
		long orderId = orderIdGenerator.getAndIncrement();
		return new Order(orderId, instrumentId, quantity, entryDate);
	}

	private Order(long orderId, long instrumentId, long quantity, Date entryDate, BigDecimal limitPrice,
			OrderType orderType) {
		this.orderId = orderId;
		this.instrumentId = instrumentId;
		this.quantity = quantity;
		this.entryDate = new Date(entryDate.getTime());
		this.limitPrice = limitPrice;
		this.orderType = orderType;
	}

	public static Order getInstance(OrderReq oreq) {
		long orderId = orderIdGenerator.getAndIncrement();
		OrderType otype = oreq.getLimitPrice() != null && BigDecimal.ZERO.compareTo(oreq.getLimitPrice()) == -1
				? OrderType.LIMIT_ORDER : OrderType.MARKET_ORDER;
		return new Order(orderId, oreq.getInstrumentId(), oreq.getQuantity(), oreq.getEntryDate(), oreq.getLimitPrice(),
				otype);
	}

	private Order(long orderId, long instrumentId, long quantity, Date entryDate) {
		this.orderId = orderId;
		this.instrumentId = instrumentId;
		this.quantity = quantity;
		this.entryDate = entryDate;
		this.orderType = OrderType.MARKET_ORDER;
	}

	public long getOrderId() {
		return orderId;
	}

	public long getInstrumentId() {
		return instrumentId;
	}

	public long getQuantity() {
		return quantity;
	}

	public Date getEntryDate() {
		return new Date(this.entryDate.getTime());
	}

	public BigDecimal getLimitPrice() {
		return limitPrice;
	}

	public OrderType getOrderType() {
		return orderType;
	}

	public String toString() {
		return JsonUtil.toJsonString(this);
	}

}
