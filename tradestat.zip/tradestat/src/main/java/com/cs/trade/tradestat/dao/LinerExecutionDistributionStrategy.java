package com.cs.trade.tradestat.dao;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

import org.springframework.stereotype.Component;

import com.cs.trade.tradestat.exception.NoNewExecutionExceptedException;
import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.OrderBook;
import com.cs.trade.tradestat.model.OrderType;
import com.cs.trade.tradestat.model.StatisticalQuantity;

@Component
public class LinerExecutionDistributionStrategy implements ExecutionDistributionStrategy {

	@Override
	public boolean executeOrder(OrderBook orderBook, Execution execution) {

		List<ExecutedOrder> execOrders = orderBook.getExecutedOrders();
		if (execOrders != null) {
			long totalDemand = countTotalValidOrders(execution, execOrders);
			if (totalDemand == 0) {
				throw new NoNewExecutionExceptedException(
						"Demand is fully fullfilled, no further execution excepted for instrument :"
								+ execution.getInstrumentId());
			}
			if (totalDemand > execution.getQuantity()) {
				calculateDistributionRatio(totalDemand, execOrders);
				executeOrder(execution, execOrders);
			} else {
				executeOrderFullQty(execution, execOrders);
			}
			return true;
		}
		return false;

	}

	public void executeOrderFullQty(Execution execution, List<ExecutedOrder> execOrders) {
		long exQty = 0;
		for (ExecutedOrder exOdr : execOrders) {
			if (exOdr.isValid()) {
				exQty = exOdr.getQuantity() - exOdr.getExecutionQuantity();
				exOdr.setExecutionQuantity(exOdr.getExecutionQuantity() + exQty);
				BigDecimal price = execution.getPrice().multiply(new BigDecimal(exQty));
				exOdr.setExecutionPrice(exOdr.getExecutionPrice().add(price));
			}
		}
	}

	public void executeOrder(Execution execution, List<ExecutedOrder> execOrders) {
		int idx = selectStatiscalCalculation(execution, execOrders);
		long exQty = 0;
		long totalExecQty = execution.getQuantity();
		PriorityQueue<ExecutedOrder> priorityQ = new PriorityQueue<ExecutedOrder>(new Comparator<ExecutedOrder>() {
			public int compare(ExecutedOrder o1, ExecutedOrder o2) {
				return (o1.getQuantity() - o1.getExecutionQuantity()) > ((o2.getQuantity() - o2.getExecutionQuantity()))
						? -1 : 1;
			};

		});
		for (ExecutedOrder exOdr : execOrders) {
			if (exOdr.isValid()) {
				switch (idx) {
				case 0:
					exQty = exOdr.getStatsCounts().getRoundQty();
					break;
				case 1:
					exQty = exOdr.getStatsCounts().getCeilQty();
					break;
				case 2:
					exQty = exOdr.getStatsCounts().getFloorQty();
				}
				totalExecQty -= exQty;
				addExecutionPriceNQty(exOdr,exQty,execution.getPrice());
				priorityQ.add(exOdr);
			}
		}
		//distribute remaining quantity, remaining quantity should be less than no of demands/orders  
		if (totalExecQty > 0) {
			for (ExecutedOrder exOdr : priorityQ) {
				if(totalExecQty > 0) {
					addExecutionPriceNQty(exOdr,1,execution.getPrice());
					totalExecQty--;
				} else {
					break;
				}
			}
		}

	}
	
	private void addExecutionPriceNQty(ExecutedOrder exOdr, long qty, BigDecimal price) {
		exOdr.setExecutionQuantity(exOdr.getExecutionQuantity() + qty);
		BigDecimal exPrice = price.multiply(new BigDecimal(qty));
		exOdr.setExecutionPrice(exOdr.getExecutionPrice().add(exPrice));
	}

	private int selectStatiscalCalculation(Execution execution, List<ExecutedOrder> execOrders) {
		StatisticalQuantity totalStats = doStatiscalCalculation(execution, execOrders);
		long diffArr[] = new long[3];
		diffArr[0] = execution.getQuantity() - totalStats.getRoundQty();
		diffArr[1] = execution.getQuantity() - totalStats.getCeilQty();
		diffArr[2] = execution.getQuantity() - totalStats.getFloorQty();

		long mindiff = Long.MAX_VALUE;
		int idx = 0;
		// find the closet way to distribute correctly
		for (int i = 0; i < 3; i++) {
			if (diffArr[i] >= 0 && mindiff > diffArr[i]) {
				mindiff = diffArr[i];
				idx = i;
			}
		}
		return idx;
	}

	private StatisticalQuantity doStatiscalCalculation(Execution execution, List<ExecutedOrder> execOrders) {
		StatisticalQuantity totalStats = new StatisticalQuantity(0, 0, 0);
		for (ExecutedOrder o : execOrders) {
			if (o.isValid()) {
				double exQty = o.getDistributionRatio() * execution.getQuantity();
				StatisticalQuantity stats = new StatisticalQuantity(Math.round(exQty), (long) Math.ceil(exQty),
						(long) Math.floor(exQty));
				o.setStatsCounts(stats);
				totalStats.setRoundQty(totalStats.getRoundQty() + stats.getRoundQty());
				totalStats.setCeilQty(totalStats.getCeilQty() + stats.getCeilQty());
				totalStats.setFloorQty(totalStats.getFloorQty() + stats.getFloorQty());
			}
		}
		return totalStats;
	}

	public void calculateDistributionRatio(long totalDemand, List<ExecutedOrder> execOrders) {
		for (ExecutedOrder o : execOrders) {
			if (o.isValid()) {
				double ratio = (double) (o.getQuantity() - o.getExecutionQuantity()) / totalDemand;
				o.setDistributionRatio(ratio);
			}
		}
	}

	public long countTotalValidOrders(Execution execution, List<ExecutedOrder> execOrders) {
		long totalDemand = 0;
		for (ExecutedOrder o : execOrders) {
			if (o.getOrderType().equals(OrderType.LIMIT_ORDER)
					&& o.getLimitPrice().compareTo(execution.getPrice()) == -1) {
				o.setValid(false);
			} else {
				o.setValid(true);
				totalDemand += (o.getQuantity() - o.getExecutionQuantity());
			}
		}
		return totalDemand;
	}
}
