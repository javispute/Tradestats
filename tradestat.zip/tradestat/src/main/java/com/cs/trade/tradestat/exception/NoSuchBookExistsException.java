package com.cs.trade.tradestat.exception;

public class NoSuchBookExistsException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public NoSuchBookExistsException() {

	}

	public NoSuchBookExistsException(Throwable th) {
		super(th);
	}
	public NoSuchBookExistsException(String msg) {
		super(msg);
	}
}
