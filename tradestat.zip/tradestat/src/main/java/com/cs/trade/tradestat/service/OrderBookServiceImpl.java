package com.cs.trade.tradestat.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cs.trade.tradestat.dao.OrderBookRepository;
import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderReq;

@Service
public class OrderBookServiceImpl implements OrderBookService {

	

	@Autowired
	private OrderBookRepository orderBookRepo;

	@Override
	public boolean openBook(long instrumentId, boolean isOpen) {
		return this.orderBookRepo.openBook(instrumentId, isOpen);
	}

	@Override
	public Order placeOrder(OrderReq orderReq) {
		if (orderReq != null) {
			Order newOrder = Order.getInstance(orderReq);
			orderBookRepo.placeOrder(newOrder);
			return newOrder;
		}
		return null;
	}

	@Override
	public ExecutedOrder getExecOrderById(long orderId) {
		return this.orderBookRepo.getExecOrderById(orderId);
	}

	@Override
	public Order getOrderById(long orderId) {
		return this.orderBookRepo.getOrderById(orderId);
	}

	@Override
	public List<Order> getOrders(long instrumentId) {
		return this.orderBookRepo.getOrders(instrumentId);
	}

	@Override
	public List<ExecutedOrder> getExecutedOrders(long instrumentId) {
		return this.orderBookRepo.getExecutedOrders(instrumentId);
	}

	@Override
	public boolean isOrderBookOpen(long instrumentId) {
		return this.orderBookRepo.isOrderBookOpen(instrumentId);
	}

	@Override
	public List<ExecutedOrder> executeBook(Execution execution) {
		return this.orderBookRepo.executeBook(execution);
	}
	
	public void setOrderBookRepo(OrderBookRepository orderBookRepo) {
		this.orderBookRepo = orderBookRepo;
	}

}
