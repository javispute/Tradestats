package com.cs.trade.tradestat.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.ExecutionStats;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBookStats;
import com.cs.trade.tradestat.model.OrderBookStatus;
import com.cs.trade.tradestat.model.OrderReq;
import com.cs.trade.tradestat.model.OrderStats;
import com.cs.trade.tradestat.service.OrderBookService;

@RestController
public class OrderBookController {
	@Autowired
	OrderBookService orderBookService;
	 
	@Autowired
	OrderBookStats orderBookStats;
     
	@GetMapping("/orderbook/{instrumentId}")
	public OrderBookStatus orderBookStatus(@PathVariable long instrumentId) {
		boolean status = orderBookService.isOrderBookOpen(instrumentId);
		return new OrderBookStatus(instrumentId, status);
	}
	
	
	@PostMapping("/orderbook/{instrumentId}/{isOpen}")
	public OrderBookStatus orderBookOp(@PathVariable long instrumentId, @PathVariable boolean isOpen) {
		boolean status = orderBookService.openBook(instrumentId, isOpen);
		return new OrderBookStatus(instrumentId, status);
	}

    
	@PostMapping("/orderbook/order")
	public Order order(OrderReq order) {
		return orderBookService.placeOrder(order);
	}

    
	@GetMapping("/orderbook/order/{orderId}")
	public Order getOrderById(@PathVariable long orderId) {
		return this.orderBookService.getOrderById(orderId);
	}

	
	@GetMapping("/orderbook/exec/{orderId}")
	public ExecutedOrder getExecutedOrderById(@PathVariable long orderId) {
		return this.orderBookService.getExecOrderById(orderId);
	}

	
	@GetMapping("/orderbook/{instrumentId}/orders")
	public List<Order> getOrders(@PathVariable long instrumentId) {
		return this.orderBookService.getOrders(instrumentId);
	}

	
	@GetMapping("/orderbook/{instrumentId}/execs")
	public List<ExecutedOrder> getExecOrders(@PathVariable long instrumentId) {
		return this.orderBookService.getExecutedOrders(instrumentId);
	}
	
	
	@PostMapping("/orderbook/exec")
	public List<ExecutedOrder> executeOrder(Execution execution) {
		System.out.println("execute orders ...");
		return this.orderBookService.executeBook(execution);
	}
	
	
	@GetMapping("/orderbook/{instrumentId}/orderstats")
	public OrderStats getOrderStats(@PathVariable long instrumentId) {
		return orderBookStats.getOrderStats(instrumentId);
	}
	
	
	@GetMapping("/orderbook/{instrumentId}/execstats")
	public ExecutionStats getOrderExecStats(@PathVariable long instrumentId) {
		return orderBookStats.getOrderExecStats(instrumentId);
	}
}
