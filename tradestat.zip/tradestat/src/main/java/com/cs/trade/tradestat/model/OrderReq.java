package com.cs.trade.tradestat.model;

import java.math.BigDecimal;
import java.util.Date;

public class OrderReq {
	private long orderId;
	private long instrumentId;
	private long quantity;
	private Date entryDate = new Date();
	private BigDecimal limitPrice;
	private OrderType orderType = OrderType.MARKET_ORDER;
	

	public OrderReq(){
	}


	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public void setInstrumentId(long instrumentId) {
		this.instrumentId = instrumentId;
	}



	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}



	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate == null ? new Date() : entryDate;
	}

	public void setLimitPrice(BigDecimal limitPrice) {
		this.limitPrice = limitPrice;
	}
	public void setOrderType(OrderType orderType) {
		this.orderType = orderType;
	}



	public long getOrderId() {
		return orderId;
	}

	public long getInstrumentId() {
		return instrumentId;
	}

	public long getQuantity() {
		return quantity;
	}

	public Date getEntryDate() {
		return this.entryDate;
	}

	public BigDecimal getLimitPrice() {
		return limitPrice;
	}

	public OrderType getOrderType() {
		return orderType;
	}
	
	/*  This method  need  to be implemented for test case to work
	 *  else mock bean is able to return the order bean
	 * (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		if(this == obj) {
			return true;
		}
	   if(obj instanceof OrderReq) {
		  OrderReq req = (OrderReq)obj;
		  if (this.instrumentId == req.instrumentId  && this.quantity==req.quantity) {
			  if(this.orderType.equals(req.orderType)) {
				  if( ( this.limitPrice == null && req.limitPrice==null) || 
						   (this.limitPrice!=null && this.limitPrice.equals(req.limitPrice) ) ) {
					  return true;
				  }
			  }
		  }
		   
	   }
	   return false;
	}



}
