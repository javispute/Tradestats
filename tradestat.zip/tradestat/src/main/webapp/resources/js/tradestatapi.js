var baseUrl="http://localhost:8080/tradestat"
$(document).ready(function(){
	
	$('ul.tabs li').click(function(){
		var tab_id = $(this).attr('data-tab');

		$('ul.tabs li').removeClass('current');
		$('.tab-content').removeClass('current');

		$(this).addClass('current');
		$("#"+tab_id).addClass('current');
	});	
	

	$('#checkstatusBtn').click(function(){
		$.ajax({
	        url: baseUrl+"/orderbook/"+$("#instId").val(),
	        type: "GET",
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw=="},
	        dataType: 'json',
	        success: function(result) {
	        	//var json = $.parseJSON(result);
	            //console.log("suc:"+json.instrumentId + ":" + json.open)        	
	        	$('#bookstatusMsg').text("instrument : " + $("#instId").val() + " is open : " +result.open);
	        },
	        error: function(result) {
	           $('#bookstatusMsg').text(result.responseJSON.message);
	        }
		 });
	});
	
	
	$('#opencloseBtn').click(function(){
		$.ajax({
	        url: baseUrl+"/orderbook/"+$("#opcinstId").val() +"/"+$("input[name='openclose']:checked").val(),
	        type: "POST",
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw=="},
	        dataType: 'json',
	        success: function(result) {
	        	    	
	        	$('#opencloseMsg').text("instrument : " + $("#instId").val() + " is open : " +result.open);
	        },
	        error: function(result) {
	           $('#opencloseMsg').text(result.responseJSON.message);
	        }
		 });
	});
	
	/*-------   Order Tab --------------------*/
	
	$('#placeOrderBtn').click(function(){
		
		var lp = $.trim( $('#polimitPrice').val() );
		var odrType = "MARKET_ORDER";
		if(lp!=""){
			odrType="LIMIT_ORDER";
		} 
			
		$.ajax({
	        url: baseUrl+"/orderbook/order",
	        type: "POST",
	        data:{"instrumentId":$('#poInstId').val(),"quantity":$('#poqty').val(), "limitPrice":lp,"orderType":odrType },
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw=="},
	        dataType: 'json',
	        success: function(result) {
	        	 $('#poMsg').html("<pre>"+JSON.stringify(result,null,'\t')+"</pre>");
	        },
	        error: function(result) {
	           $('#poMsg').text(result.responseJSON.message);
	        }
		 });
	});
	
	$('#orderByIdBtn').click(function(){
		$.ajax({
	        url: baseUrl+"/orderbook/order/"+$("#OdrByOId").val() ,
	        type: "GET",
	        dataType: 'json',
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw=="},
	        success: function(result) {
	        	if(result == "") {
	        		$('#odrByIdMsg').text("Order does not exists for id :" +$("#OdrByOId").val());
	        	} else {
	        	  $('#odrByIdMsg').html("<pre>"+JSON.stringify(result,null,'\t')+"</pre>");
	        	}
	        },
	        error: function(result) {
	        	if(result.responseText == "" && result.status==200) {
	        		$('#odrByIdMsg').text("Order does not exists for id :" +$("#OdrByOId").val() );	
	        	} else {
	        		$('#odrByIdMsg').text("Some error occured ");
	        	}
	           
	        }
		 });
	});
	
   $('#ordersBtn').click(function(){
		
		var lp = $.trim( $('#polimitPrice').val() );
		var odrType = "MARKET_ORDER";
		if(lp!=""){
			odrType="LIMIT_ORDER";
		} 
			
		$.ajax({
	        url: baseUrl+"/orderbook/"+$('#oinstId').val() +"/orders",
	        type: "GET",
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw=="},
	        dataType: 'json',
	        success: function(result) {
	        	var html="<table><tr><td>OrderId</td><td>InstrumentId</td><td>Quantity</td><td>OrderType</td><td>Limit Price</td></tr>";
	        	$.each(result, function(key, value) {
	        		html = html + "<tr><td> " + value.orderId + " </td><td> "+value.instrumentId+" </td><td> "+value.quantity+" </td><td> "+value.orderType+" </td><td> "+value.limitPrice+" </td></tr>";
	        	});
	        	html = html + "</table>";
	        	$('#ordersMsg').html(html);
	        },
	        error: function(result) {
	           $('#ordersMsg').text(result.responseJSON.message);
	        }
		 });
	});
   
   /*-------   Execution Tab --------------------*/
   $('#execBtn').click(function(){
		
		$.ajax({
	        url: baseUrl+"/orderbook/exec",
	        type: "POST",
	        data:{"instrumentId":$('#execInstId').val(),"quantity":$('#execqty').val(), "price":$('#execPrice').val() },
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw=="},
	        dataType: 'json',
	        success: dispExecOrders,
	        error: function(result) {
	           $('#execOrdersMsg').text(result.responseJSON.message);
	        }
		 });
	});
   
    $('#execOrdersBtn').click(function(){
		
		$.ajax({
	        url: baseUrl+"/orderbook/"+$('#eInstId').val()+"/execs",
	        type: "GET",
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw=="},
	        dataType: 'json',
	        success: dispExecOrders,
	        error: function(result) {
	           $('#execOrdersMsg').text(result.responseJSON.message);
	        }
		 });
	});
   
    var dispExecOrders = function(result){
    	var html="<table><tr><td>OrderId</td><td>InstrumentId</td><td>Quantity</td><td>OrderType</td><td>Limit Price</td><td>isValid</td><td>Unit Exec Price</td><td>Execution Quantity</td><td>Execution Price</td></tr>";
    	$.each(result, function(key, value) {
    		html = html + "<tr><td> " + value.orderId + " </td><td> "+value.instrumentId+" </td><td> "+value.quantity+" </td><td> "+value.orderType+" </td><td> "+value.limitPrice+" </td><td> "+value.valid+" </td><td> "+ value.unitExecutionPrice +" </td><td> "+ value.executionQuantity+" </td><td> "+value.executionPrice+"</td></tr>";
    	});
    	html = html + "</table>";
    	$('#execOrdersMsg').html(html);
    }
	
    $('#execByIdBtn').click(function(){
		$.ajax({
	        url: baseUrl+"/orderbook/exec/"+$("#execById").val() ,
	        type: "GET",
	        dataType: 'json',
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw=="},
	        success: function(result) {
	        	  $('#execByIdMsg').html("<pre>"+JSON.stringify(result,null,'\t')+"</pre>");
	        },
	        error: function(result) {
	        	if(result.responseText == "" && result.status==200) {
	        		$('#execByIdMsg').text("Order does not exists for id :" +$("#execById").val() );	
	        	} else {
	        		$('#execByIdMsg').text("Some error occured ");
	        	}
	           
	        }
		 });
	});
    
    $('#statsBtn').click(function(){
    	$.ajax({
	        url: baseUrl+"/orderbook/"+$("#statsInstId").val() +"/"+$("input[name='stats']:checked").val(),
	        type: "GET",
	        headers: {Authorization:"Basic Y3N1c2VyOmNzdXNlcjEyMw=="},
	        dataType: 'json',
	        success: function(result) {
	        	$('#statsMsg').html("<pre>"+JSON.stringify(result,null, '\t')+"</pre>");
	        },
	        error: function(result) {
	           $('#statsMsg').text(result.responseJSON.message);
	        }
		 });
    });
	
});



