package com.cs.trade.tradestat.controller;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;

import com.cs.trade.tradestat.dao.LinerExecutionDistributionStrategy;
import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.ExecutionStats;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderBook;
import com.cs.trade.tradestat.model.OrderBookStats;
import com.cs.trade.tradestat.model.OrderReq;
import com.cs.trade.tradestat.model.OrderStats;
import com.cs.trade.tradestat.model.OrderType;
import com.cs.trade.tradestat.service.OrderBookService;
import com.cs.trade.tradestat.util.BeanCreationUtil;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class OrderBookControllerTest {
	
	@LocalServerPort
	private int port;
    private static String user="csuser";
    private static String password="csuser123";
	private String uri;

	@MockBean
	OrderBookService svc;
	
	@MockBean
	OrderBookStats stats;
	
	static long instrumentId = 1234;

	@PostConstruct
	public void init() {
		uri = "http://localhost:" + port +"/tradestat";
	}

	@Test
	public void testOpenBook() {
		when(svc.openBook(instrumentId, true)).thenReturn(true);
		
		given()
		      .auth().preemptive().basic(user, password)
		.when()
			.post(uri + "/orderbook/" + instrumentId + "/true")
		.then()
		    .assertThat()
				.statusCode(HttpStatus.OK.value())
			  .and()
			    .body("instrumentId", equalTo(1234))
			  .and()
				.body("open", equalTo(true));
	}
	
	@Test
	public void testCloseBook() {
		when(svc.openBook(instrumentId, false)).thenReturn(false);
		given()
		    .auth().preemptive().basic(user, password)
		.when()
		 .post(uri + "/orderbook/" + instrumentId + "/false").
		  then().
		     assertThat().
				statusCode(HttpStatus.OK.value()).
				 and().
				body("instrumentId", equalTo(1234)).
				  and().
				body("open", equalTo(false));
	}

	@Test
	public void testPlaceMarketOrder() {
		OrderReq oreq = new OrderReq();
		oreq.setInstrumentId(instrumentId);
		oreq.setQuantity(34);

		Order order = Order.getInstance(oreq);
		when(svc.placeOrder(oreq)).thenReturn(order);

		Map<String, String> request = new HashMap<>();
		request.put("instrumentId", "1234");
		request.put("quantity", "34");

		given()
		    .auth().preemptive().basic(user, password)
		.when()
		    .formParams(request).post(uri + "/orderbook/order")
		    .then()
		    .assertThat()
			.statusCode(HttpStatus.OK.value())
				.assertThat().
					body("instrumentId", equalTo(1234)).
					 and().
					body("quantity", equalTo(34)).
					  and().
					body("orderType", equalTo("MARKET_ORDER"));
	}

	@Test
	public void testPlaceLimitOrder() {
		
		OrderReq oreq = new OrderReq();
		oreq.setInstrumentId(instrumentId);
		oreq.setQuantity(34);
		oreq.setLimitPrice(new BigDecimal(450));
		oreq.setOrderType(OrderType.LIMIT_ORDER);

		Order order = Order.getInstance(oreq);
		when(svc.placeOrder(oreq)).thenReturn(order);

		Map<String, Object> request = new HashMap<>();
		request.put("instrumentId", "1234");
		request.put("quantity", "34");
		request.put("limitPrice", 450);
		request.put("orderType", OrderType.LIMIT_ORDER);


		given()
		    .auth().preemptive().basic(user, password)
		.when()
		    .formParams(request).post(uri + "/orderbook/order")
		    .then()
		    .assertThat()
			 .statusCode(HttpStatus.OK.value())
			 .assertThat().
				body("instrumentId", equalTo(1234)).
				 and().
				body("quantity", equalTo(34)).
				  and().
				body("orderType", equalTo("LIMIT_ORDER")).
				 and().
				body("limitPrice", equalTo(450));
		;
	}

	@Test
	public void testGetOrderById() {

		Order order = BeanCreationUtil.createMarketOrder(instrumentId, 34);

		when(svc.getOrderById(1)).thenReturn(order);

		given()
		  .auth().preemptive().basic(user, password)
		.when()
		.get(uri + "/orderbook/order/1")
		.then()
		.assertThat()
		.statusCode(HttpStatus.OK.value())
		.contentType("application/json")
		.assertThat()
		.body("instrumentId", equalTo(1234))
		   .and()
		.body("quantity", equalTo(34))
		   .and()
		.body("orderType", equalTo("MARKET_ORDER"));
	}

	@Test
	public void testGetExecOrderById() {

		Order order = BeanCreationUtil.createMarketOrder(instrumentId, 34);
		ExecutedOrder execOrder = new ExecutedOrder(order);
		when(svc.getExecOrderById(1)).thenReturn(execOrder);

		given()
		   .auth().preemptive().basic(user, password)
		.when()
			.get(uri + "/orderbook/exec/1")
			.then()
			.assertThat()
				.statusCode(HttpStatus.OK.value())
				.contentType("application/json")
				.assertThat()
				.body("instrumentId", equalTo(1234))
				   .and()
				.body("quantity", equalTo(34))
				   .and()
				.body("valid", equalTo(false))
				   .and()
				.body("orderType", equalTo("MARKET_ORDER"));

	}

	@Test
	public void testGetOrders() {

		List<Order> list = new ArrayList<>();
		
		Order order = BeanCreationUtil.createMarketOrder(instrumentId, 34);
		Order order1 =BeanCreationUtil.createMarketOrder(instrumentId, 50);
		list.add(order);
		list.add(order1);
		
		when(svc.getOrders(instrumentId)).thenReturn(list);

		given()
		   .auth().preemptive().basic(user, password)
		.when()
 		 .get(uri + "/orderbook/"+instrumentId+"/orders")
		 .then()
		 .assertThat()
			.statusCode(HttpStatus.OK.value())
			.contentType("application/json")
			.assertThat()
			.body("size()", is(2));

	}
	
	@Test
	public void testGetExecOrders() {

		List<ExecutedOrder> list = new ArrayList<>();
		
		Order order = BeanCreationUtil.createMarketOrder(instrumentId, 34);
		Order order1 =BeanCreationUtil.createMarketOrder(instrumentId, 50);
		list.add(new ExecutedOrder(order));
		list.add(new ExecutedOrder(order1));
		
		when(svc.getExecutedOrders(instrumentId)).thenReturn(list);

		given()
		   .auth().preemptive().basic(user, password)
		.when()
		.get(uri + "/orderbook/"+instrumentId+"/execs")
		.then()
		.assertThat()
			.statusCode(HttpStatus.OK.value())
			.contentType("application/json")
			.assertThat()
			.body("size()", is(2));

	}
	
	@Test
	public void testExecuteBook() {

		
		Execution execution = BeanCreationUtil.createExecution(instrumentId, 100, 50);
		List<ExecutedOrder> list = new ArrayList<>();
		
		Order order = BeanCreationUtil.createMarketOrder(instrumentId, 34);
		Order order1 =BeanCreationUtil.createMarketOrder(instrumentId, 50);
		list.add(new ExecutedOrder(order));
		list.add(new ExecutedOrder(order1));
		
		when(svc.executeBook(execution)).thenReturn(list);
		
		Map<String, Object> params = new HashMap<>();
		params.put("instrumentId", instrumentId);
		params.put("quantity", 100);
		params.put("price", new BigDecimal(50));

		given()
		   .auth().preemptive().basic(user, password)
		.when()
			.formParams(params)
			.post(uri + "/orderbook/exec")
			.then()
			.assertThat()
			.statusCode(HttpStatus.OK.value())
			.contentType("application/json")
			.assertThat()
			.body("size()", is(2));

	}
	
	@Test
	public void testGetOrderStats() {
		
		Order order = BeanCreationUtil.createLimitPriceOrder(instrumentId,80,55);
		Order order1 =BeanCreationUtil.createMarketOrder(instrumentId, 50);
		Order order2 = BeanCreationUtil.createLimitPriceOrder(instrumentId,30,45);
		OrderStats orderstats = new OrderStats();
		orderstats.updateStats( order);
		orderstats.updateStats( order1);
		orderstats.updateStats( order2);
		
		when(stats.getOrderStats(instrumentId)).thenReturn(orderstats);
	

		given()
		   .auth().preemptive().basic(user, password)
		.when()
		.get(uri + "/orderbook/"+instrumentId+"/orderstats")
		.then()
		.assertThat()
			.statusCode(HttpStatus.OK.value())
			.contentType("application/json")
			.assertThat()
			.body("totalOrderCount", is(3))
			   .and()
			.body("earliestOrder.orderId", equalTo((int)order.getOrderId()))
			   .and()
			.body("earliestOrder.orderType", equalTo(order.getOrderType().toString()))
			   .and()
			.body("lastOrder.orderId", equalTo((int)order2.getOrderId()))
			   .and()
			.body("lastOrder.orderType", equalTo(order2.getOrderType().toString()))  ;

	}
	
	@Test
	public void testGetOrderExecStats() {
		

		Order order = BeanCreationUtil.createLimitPriceOrder(instrumentId,80,55);
		Order order1 =BeanCreationUtil.createMarketOrder(instrumentId, 50);
		Order order2 = BeanCreationUtil.createLimitPriceOrder(instrumentId,30, 45);

		OrderBook book = new OrderBook(instrumentId);
		book.addExecOrder(new ExecutedOrder( order));
		book.addExecOrder(new ExecutedOrder( order1));
		book.addExecOrder(new ExecutedOrder( order2));
		
		ExecutionStats execStats = new ExecutionStats();
		
		Execution execution = BeanCreationUtil.createExecution(instrumentId, 100, 55);
		new LinerExecutionDistributionStrategy().executeOrder(book, execution);
		
		execStats.updateExecStats(book.getExecutedOrders());
		
		when(stats.getOrderExecStats(instrumentId)).thenReturn(execStats);
	

		given()
		   .auth().preemptive().basic(user, password)
		.when()
		.get(uri + "/orderbook/"+instrumentId+"/execstats")
		.then()
		.assertThat()
			.statusCode(HttpStatus.OK.value())
			.contentType("application/json")
			.assertThat()
			.body("validDemand", is(130))
			   .and()
			.body("invalidDemand", is(30))
			   .and()   
			.body("totalValidDemandCount", is(2))
			   .and()
			.body("totalInvalidDemandCount", is(1))
				   .and()
			.body("accumulatedQuantiy", is(100))
				.and()
			.body("accumulatedPrice", is(5500))
				.and()   
			.body("earliestOrder.orderId", equalTo((int)order.getOrderId()))
			   .and()
			.body("earliestOrder.orderType", equalTo(order.getOrderType().toString()))
			  .and()
			.body("earliestOrder.quantity", equalTo((int)order.getQuantity()))
			   .and()
			.body("lastOrder.orderId", equalTo((int)order2.getOrderId()))
			   .and()
			.body("lastOrder.orderType", equalTo(order2.getOrderType().toString()))
			   .and()
		     .body("biggestOrder.orderId", equalTo((int)order.getOrderId()))
		       .and()
		     .body("biggestOrder.orderType", equalTo(order.getOrderType().toString()))
		         .and()
			 .body("biggestOrder.quantity", equalTo((int)order.getQuantity()))
			   .and()
	
		     .body("smallestOrder.orderId", equalTo((int)order2.getOrderId()))
		       .and()
		     .body("smallestOrder.orderType", equalTo(order2.getOrderType().toString()))
	     	   .and()
		     .body("smallestOrder.quantity", equalTo((int)order2.getQuantity()));
	}
}
