package com.cs.trade.tradestat.service;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cs.trade.tradestat.dao.OrderBookRepository;
import com.cs.trade.tradestat.exception.CloseBookException;
import com.cs.trade.tradestat.exception.NoNewExecutionExceptedException;
import com.cs.trade.tradestat.exception.NoSuchBookExistsException;
import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.model.OrderReq;
import com.cs.trade.tradestat.model.OrderType;
import com.cs.trade.tradestat.util.BeanCreationUtil;
@RunWith(SpringJUnit4ClassRunner.class)
public class OrderBookServiceTest {

	OrderBookRepository repo = Mockito.mock(OrderBookRepository.class);
	
	OrderBookServiceImpl svc = new OrderBookServiceImpl();

	static long instrumentId = 1234;
	public OrderBookServiceTest() {
		this.svc.setOrderBookRepo(repo);
	}

	@Before
	public void openBook() {
		when(this.repo.openBook(instrumentId, true)).thenReturn(true);
		assertThat(this.svc.openBook(instrumentId, true), equalTo(true));
	}

	@Test
	public void testIsBookOpen() {
		when(this.repo.isOrderBookOpen(instrumentId)).thenReturn(true);
		assertThat(this.svc.isOrderBookOpen(instrumentId), equalTo(true));
	}

	@Test
	public void testCloseBook() {
		
		when(this.repo.openBook(instrumentId, false)).thenReturn(false);
		when(this.repo.isOrderBookOpen(instrumentId)).thenReturn(false);
		assertThat(false, equalTo(this.svc.isOrderBookOpen(instrumentId)));
	}

	@Test(expected = NoSuchBookExistsException.class)
	public void testCloseBook_withoutOpeningIt() {
		when(this.repo.openBook(2345,false)).thenThrow(new NoSuchBookExistsException("No Such book exists : " + instrumentId));
		this.svc.openBook(2345, false);
	}


	@Test(expected = NoSuchBookExistsException.class)
	public void testIsBookOpen_UnknowInstrument() {
		when(this.repo.isOrderBookOpen(2345)).thenThrow(new NoSuchBookExistsException("No such book exists"));
		this.svc.isOrderBookOpen(2345);
	}

	@Test
	public void testPlaceOrderForOpenBook() {
		when(this.repo.placeOrder(Mockito.any())).thenReturn(true);
		OrderReq orderReq = BeanCreationUtil.createMarketOrderReq(instrumentId,50);
		Order order = this.svc.placeOrder(orderReq);
		assertThat(order, is(notNullValue()));
		assertThat(orderReq.getInstrumentId(), equalTo(order.getInstrumentId()));
		assertThat(orderReq.getQuantity(), equalTo(order.getQuantity()));
		assertThat(OrderType.MARKET_ORDER, equalTo(order.getOrderType()));
	}
	
	@Test(expected=CloseBookException.class)
	public void testPlaceOrderForCloseBook() {
		when(this.repo.placeOrder(Mockito.any())).thenThrow(new CloseBookException("Order Book is closed for instrument : " + instrumentId));
		OrderReq orderReq = BeanCreationUtil.createMarketOrderReq(instrumentId,50);
		this.svc.placeOrder(orderReq);
	}

	@Test(expected=NoSuchBookExistsException.class)
	public void testPlaceOrderForNonExistingBook() {
		when(this.repo.placeOrder(Mockito.any())).thenThrow(new NoSuchBookExistsException("No book exists for instrument :" + 2345));
		OrderReq orderReq = BeanCreationUtil.createMarketOrderReq(2345,50);
		this.svc.placeOrder(orderReq);
	}
	
	@Test
	public void testGetOrders() {
		List<Order> orders = getOrderList();
        when(this.repo.getOrders(instrumentId)).thenReturn(orders);
        List<Order> orderList = this.svc.getOrders(instrumentId);
		assertThat(orderList, hasSize(2));
		assertThat(orderList, equalTo(orders));
	}

	
	@Test
	public void testGetExecOrders() {
		List<ExecutedOrder> orders = getExecOrderList();
        when(this.repo.getExecutedOrders(instrumentId)).thenReturn(orders);
        List<ExecutedOrder> orderList = this.svc.getExecutedOrders(instrumentId);
		assertThat(orderList, hasSize(2));
		assertThat(orderList, equalTo(orders));
	}
	
	@Test
	public void testGetOrderById() {
		Order order = BeanCreationUtil.createMarketPriceOrder(instrumentId,50);
        when(this.repo.getOrderById(order.getOrderId())).thenReturn(order);
        Order ordr = this.svc.getOrderById(order.getOrderId());         
		assertThat(ordr, equalTo(order));
	}

	@Test
	public void testGetExecOrderById() {
		Order order = BeanCreationUtil.createMarketPriceOrder(instrumentId,50);
		ExecutedOrder exOdr = new ExecutedOrder(order);
        when(this.repo.getExecOrderById(order.getOrderId())).thenReturn(exOdr);
        ExecutedOrder ordr = this.svc.getExecOrderById(order.getOrderId());         
		assertThat(ordr, equalTo(exOdr));
	}

	@Test
	public void testExecuteBook() {
		Execution execution = BeanCreationUtil.createExecution(instrumentId, 100, 50);
		List<ExecutedOrder> exOrdrs = getExecOrderList();
		when(this.repo.executeBook(execution)).thenReturn(exOrdrs);
		List<ExecutedOrder> exordrList = this.svc.executeBook(execution);
		assertThat(exordrList, hasSize(2));
		assertThat(exordrList, equalTo(exOrdrs));
		
	}
	@Test(expected=NoNewExecutionExceptedException.class)
	public void testExecuteBookForOpenBook(){
		Execution execution = BeanCreationUtil.createExecution(instrumentId, 100, 50);
		when(this.repo.executeBook(Mockito.any())).thenThrow(new NoNewExecutionExceptedException("Book is open, book can't be executed."));
		this.svc.executeBook(execution);
	}
	
	private List<ExecutedOrder> getExecOrderList() {
		List<ExecutedOrder> orders = new ArrayList<>();
		Order order = BeanCreationUtil.createMarketPriceOrder(instrumentId,50);
		Order order2 = BeanCreationUtil.createLimitPriceOrder(instrumentId,80,25);
        orders.add(new ExecutedOrder(order));
        orders.add(new ExecutedOrder(order2));
        return orders;
	}
	private List<Order> getOrderList() {
		List<Order> orders = new ArrayList<>();
		Order order = BeanCreationUtil.createMarketPriceOrder(instrumentId,50);
		Order order2 = BeanCreationUtil.createLimitPriceOrder(instrumentId,80,25);
        orders.add(order);
        orders.add(order2);
        return orders;
	}

}
