package com.cs.trade.tradestat.dao;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.cs.trade.tradestat.exception.CloseBookException;
import com.cs.trade.tradestat.exception.NoNewExecutionExceptedException;
import com.cs.trade.tradestat.exception.NoSuchBookExistsException;
import com.cs.trade.tradestat.model.ExecutedOrder;
import com.cs.trade.tradestat.model.Execution;
import com.cs.trade.tradestat.model.Order;
import com.cs.trade.tradestat.util.BeanCreationUtil;

public class OrderBookRepositoryTest {

	OrderBookRepository repo = new OrderBookRepository();
	static long instrumentId = 1234;

	@Before
	public void openBook() {
		this.repo.setExecutionDistributor(new LinerExecutionDistributionStrategy());
		this.repo.openBook(instrumentId,true);
		assertThat(this.repo.getOrderBook(instrumentId), is(notNullValue()));
		assertThat(true, equalTo(this.repo.getOrderBook(instrumentId).isOpen()));

	}

	@Test
	public void testOpenBook() {
	}

	@Test
	public void testCloseBook() {
		this.repo.openBook(instrumentId,false);
		assertThat(false, equalTo(this.repo.getOrderBook(instrumentId).isOpen()));
	}

	@Test(expected = NoSuchBookExistsException.class)
	public void testCloseBook_withoutOpeningIt() {
		this.repo.openBook(2345, false);
	}

	@Test
	public void testIsBookOpen() {
		assertThat(true, equalTo(this.repo.isOrderBookOpen(instrumentId)));
	}

	@Test(expected=NoSuchBookExistsException.class)
	public void testIsBookOpen_UnknowInstrument() {
		assertThat(false, equalTo(this.repo.isOrderBookOpen(2345)));
	}

	@Test
	public void testPlaceOrder() {
		Order order = BeanCreationUtil.createMarketPriceOrder(instrumentId,50);
		assertThat(true, equalTo(this.repo.placeOrder(order)));
		ExecutedOrder exOdr = this.repo.getExecOrderById(order.getOrderId());
		assertThat(exOdr, is(notNullValue()));
		assertThat(order.getOrderId(), equalTo(exOdr.getOrderId()));
		assertThat(order, equalTo(this.repo.getOrderById(order.getOrderId())));
	}
	
	@Test(expected=CloseBookException.class)
	public void testPlaceOrderInClosedBook() {
		this.repo.openBook(instrumentId, false);
		Order order = BeanCreationUtil.createMarketPriceOrder(instrumentId,50);
		this.repo.placeOrder(order);
	}
	
	@Test(expected=NoSuchBookExistsException.class)
	public void testPlaceOrderForInstrumentOrderBookNotExists() {
		Order order = BeanCreationUtil.createMarketPriceOrder(3456,50);
		this.repo.placeOrder(order);
	}

	@Test
	public void testGetOrders() {
		Order order = BeanCreationUtil.createMarketPriceOrder(instrumentId,50);
		assertThat(true, equalTo(this.repo.placeOrder(order)));
		Order order2 = BeanCreationUtil.createLimitPriceOrder(instrumentId,80,25);
		assertThat(true, equalTo(this.repo.placeOrder(order2)));
		assertThat(this.repo.getOrders(instrumentId), hasSize(2));
		assertThat(this.repo.getOrders(instrumentId), contains(order, order2));
		assertThat(this.repo.getExecutedOrders(instrumentId), hasSize(2));
	}

	@Test
	public void testExecuteBook() {
		Order order = BeanCreationUtil.createMarketPriceOrder(instrumentId,50);
		assertThat(true, equalTo(this.repo.placeOrder(order)));
		Order order2 = BeanCreationUtil.createLimitPriceOrder(instrumentId,80,25);
		assertThat(true, equalTo(this.repo.placeOrder(order2)));
		long quantity = order.getQuantity() + order2.getQuantity()  - 1;
		long price =order2.getLimitPrice().subtract(new BigDecimal(1)).longValue();
		Execution exec = BeanCreationUtil.createExecution(instrumentId, quantity, price);
		this.repo.openBook(instrumentId, false);
		this.repo.executeBook(exec);
		assertThat(this.repo.getExecutedOrders(instrumentId), hasSize(2));
		List<ExecutedOrder> execList = this.repo.getExecutedOrders(instrumentId);
		assertThat(execList.get(0).isValid(),is(Boolean.TRUE));
		assertThat(execList.get(1).isValid(),is(Boolean.TRUE));
		
	}
	
	@Test
	public void testExecuteBookFullQuantity() {
		Order order = BeanCreationUtil.createMarketPriceOrder(instrumentId,50);
		assertThat(true, equalTo(this.repo.placeOrder(order)));
		Order order2 = BeanCreationUtil.createLimitPriceOrder(instrumentId,80,25);
		assertThat(true, equalTo(this.repo.placeOrder(order2)));
		long quantity = order.getQuantity() + order2.getQuantity();
		long price =order2.getLimitPrice().subtract(new BigDecimal(1)).longValue();
		Execution exec = BeanCreationUtil.createExecution(instrumentId, quantity, price);
		this.repo.openBook(instrumentId, false);
		this.repo.executeBook(exec);
		assertThat(this.repo.getExecutedOrders(instrumentId), hasSize(2));
		List<ExecutedOrder> execList = this.repo.getExecutedOrders(instrumentId);
		assertThat(execList.get(0).isValid(),is(Boolean.TRUE));
		assertThat(execList.get(1).isValid(),is(Boolean.TRUE));
		
	}
	@Test(expected=NoNewExecutionExceptedException.class)
	public void testExecuteBookForOpenBook(){
			Order order = BeanCreationUtil.createMarketPriceOrder(instrumentId,50);
			assertThat(true, equalTo(this.repo.placeOrder(order)));
			Order order2 = BeanCreationUtil.createLimitPriceOrder(instrumentId,80,25);
			assertThat(true, equalTo(this.repo.placeOrder(order2)));
			Execution exec = BeanCreationUtil.createExecution(instrumentId, 20, 45);
			this.repo.executeBook(exec);
	}

}
