**open or close Book**
----
  
* **URL**

    /orderbook/{:instrumentId}/{:isopen}

* **Method:**
  
     `POST` 
  
*  **URL Params**

   
   **Required:**
 
      `instrumentId=[long]`
      `isopen=[boolean]`

*  **Optional:**
 
      None


* **Success Response:**
  
   * **Code:** 
     
              200
   * **Content:** 
   
           true | false
 
* **Error Response:**
     
      None
  
* **Sample Call:**

       url: "/orderbook/12345/true", 

* **Notes:**


----

** Place Order**
----
  
* **URL**

     /orderbook/order?instrumentId=:instrumentId&quantity=:quantity&limitPrice=:limitPrice&orderType=:orderType

* **Method:**
  
     `POST` 
  
*  **Form Params**

   
*   **Required:**
 
     `instrumentId=[long]`
      `quantity=[long]`

*  **Optional:**
 
      `limitPrice=[BigDecimal]`
      `orderType=[LIMIT_ORDER | MARKET_ORDER ]`


* **Success Response:**
  
   * **Code:** 
         
           200 
   * **Content:** 
   
			 `{
			    "orderId": 5,
			    "instrumentId": 1234,
			    "quantity": 50,
			    "entryDate": "2019-04-13T02:33:39.129+0000",
			    "limitPrice": null,
			    "orderType": "MARKET_ORDER"
			  }`
 
* **Error Response:**
     
      {
         "timestamp": "2019-04-13T02:33:39.129+0000",
         "status": 500,
          "error": "Internal Server Error",
          "message": "Order Book is closed for instrument : 1234",
           "path": "/orderbook/order"
        }
  
* **Sample Call:**

     url: "/orderbook/order?instrumentId=12345&quantity=55", 
     url: "/orderbook/order?instrumentId=12345&quantity=55&limitPrice=40&orderType=LIMIT_ORDER"
    
* **Notes:**
     
     Please note if only instrument id and quantity is provided then by default it's MARKET_ORDER type.
     Order can be placed only and only if the order book is open for instrument.
 
---- 

** View All Orders**
----
  
* **URL**

    /orderbook/{instrumentId}/orders

* **Method:**
  
     `GET` 
  
*  **Path Params**

   
*   **Required:**
 
     `instrumentId=[long]`
      

*  **Optional:**
 
      `None`


* **Success Response:**
  
   * **Code:** 
            
             200 
   * **Content:** 
   
              [
				    {
				        "orderId": 1,
				        "instrumentId": 1234,
				        "quantity": 40,
				        "entryDate": "2019-04-13T02:33:39.129+0000",
				        "limitPrice": 16,
				        "orderType": "LIMIT_ORDER"
				    },
				    {
				        "orderId": 2,
				        "instrumentId": 1234,
				        "quantity": 50,
				        "entryDate": "2019-04-13T02:33:39.129+0000",
				        "limitPrice": 16,
				        "orderType": "LIMIT_ORDER"
				    },
				    {
				        "orderId": 3,
				        "instrumentId": 1234,
				        "quantity": 50,
				        "entryDate": "2019-04-13T02:33:39.129+0000",
				        "limitPrice": null,
				        "orderType": "MARKET_ORDER"
				    }
				]
             
 
* **Error Response:**
     
      None
  
* **Sample Call:**

      url: "/orderbook/1234/orders 
        
* **Notes:**
     
   
----
     

** View All Order executions**
----
  
* **URL**

     /orderbook/{instrumentId}/execs

* **Method:**
  
     `GET` 
  
*  **Path Params**

   
*    **Required:**
 
     `instrumentId=[long]`
      

*   **Optional:**
 
      `None`


* **Success Response:**
  
   * **Code:** 
   
            200 
   * **Content:** 
     
			 [
			    {
			        "orderId": 1,
			        "instrumentId": 1234,
			        "quantity": 40,
			        "limitPrice": 20,
			        "orderType": "LIMIT_ORDER",
			        "executionQuantity": 40,
			        "executionPrice": 800,
			        "valid": true
			    },
			    {
			        "orderId": 2,
			        "instrumentId": 1234,
			        "quantity": 50,
			        "limitPrice": 16,
			        "orderType": "LIMIT_ORDER",
			        "executionQuantity": 0,
			        "executionPrice": 0,
			        "valid": false
			    },
			    {
			        "orderId": 3,
			        "instrumentId": 1234,
			        "quantity": 50,
			        "limitPrice": null,
			        "orderType": "MARKET_ORDER",
			        "executionQuantity": 50,
			        "executionPrice": 1000,
			        "valid": true
			    },
			]     
      
* **Error Response:**
     
      None
  
* **Sample Call:**

    url: "/orderbook/1234/execs 
        
* **Notes:**   

----


** View Order By Order Id**
----
  
* **URL**

     /orderbook/order/{orderId}

* **Method:**
  
     `GET` 
  
*  **Path Params**

   
*    **Required:**
 
     `orderId=[long]`
      

*   **Optional:**
 
      `None`


* **Success Response:**
  
   * **Code:** 
   
            200 
   * **Content:** 
     
			     {
				    "orderId": 1,
				    "instrumentId": 1234,
				    "quantity": 40,
				    "entryDate": "2019-04-13T02:33:39.129+0000",
				    "limitPrice": 16,
				    "orderType": "LIMIT_ORDER"
                }
      
* **Error Response:**
     
      None
  
* **Sample Call:**

    url: "/orderbook/order/1 
        
* **Notes:**   

----


** Execute Order**
----
  
* **URL**

     /orderbook/exec

* **Method:**
  
     `POST` 
  
*  **Form Params**

   
*    **Required:**
 
     `instrumentId=[long]`
     `quantity=[long]`
     `price=[BigDecimal]`
      

*   **Optional:**
 
      `None`


* **Success Response:**
  
   * **Code:** 
   
            200 
   * **Content:** 
     
		 [
			    {
			        "orderId": 1,
			        "instrumentId": 1234,
			        "quantity": 40,
			        "limitPrice": 20,
			        "orderType": "LIMIT_ORDER",
			        "executionQuantity": 40,
			        "executionPrice": 800,
			        "valid": true
			    },
			    {
			        "orderId": 2,
			        "instrumentId": 1234,
			        "quantity": 50,
			        "limitPrice": 16,
			        "orderType": "LIMIT_ORDER",
			        "executionQuantity": 0,
			        "executionPrice": 0,
			        "valid": false
			    },
			    {
			        "orderId": 3,
			        "instrumentId": 1234,
			        "quantity": 50,
			        "limitPrice": null,
			        "orderType": "MARKET_ORDER",
			        "executionQuantity": 50,
			        "executionPrice": 1000,
			        "valid": true
			    },
			]    
      
* **Error Response:**
     
      {
		    "timestamp": "2019-04-13T02:33:39.129+0000",
		    "status": 500,
		    "error": "Internal Server Error",
		    "message": "Book is open, book can't be executed.",
		    "path": "/orderbook/exec"
		}
  
* **Sample Call:**

    url: "/orderbook/exec
        
* **Notes:**   
     
      Order execution can be accepted if book is closed for instrument.
      if quantity in execution is less than total demand, then quantity is distributed based ratio individual order demand / total demand.
      
-----


** View Order stats**
----
  
* **URL**

     /orderbook/{instrumentId}/orderstats

* **Method:**
  
     `GET` 
  
*  **Path Params**

   
*    **Required:**
 
     `instrumentId=[long]`
      

*   **Optional:**
 
      `None`


* **Success Response:**
  
   * **Code:** 
   
            200 
   * **Content:** 
     
				{
				    "totalOrderCount": 4,
				    "totalDemand": 190,
				    "biggestOrder": {
				        "orderId": 2,
				        "instrumentId": 1234,
				        "quantity": 50,
				        "entryDate": "2019-04-13T02:33:39.129+0000",
				        "limitPrice": 16,
				        "orderType": "LIMIT_ORDER"
				    },
				    "smallestOrder": {
				        "orderId": 1,
				        "instrumentId": 1234,
				        "quantity": 40,
				        "entryDate": "2019-04-13T02:33:39.129+0000",
				        "limitPrice": 16,
				        "orderType": "LIMIT_ORDER"
				    },
				    "earliestOrder": {
				        "orderId": 1,
				        "instrumentId": 1234,
				        "quantity": 40,
				        "entryDate": "2019-04-13T02:33:39.129+0000",
				        "limitPrice": 16,
				        "orderType": "LIMIT_ORDER"
				    },
				    "lastOrder": {
				        "orderId": 5,
				        "instrumentId": 1234,
				        "quantity": 50,
				        "entryDate": "2019-04-13T02:33:39.129+0000",
				        "limitPrice": null,
				        "orderType": "MARKET_ORDER"
				    },
				    "limitPriceDemandMap": {
				        "16": 90
				    }
				}      
* **Error Response:**
     
      None
  
* **Sample Call:**

    url: "/orderbook/1234/orderstats 
        
* **Notes:**   

----

** View Order Execution stats**
----
  
* **URL**

     /orderbook/{instrumentId}/execstats

* **Method:**
  
     `GET` 
  
*  **Path Params**

   
*    **Required:**
 
     `instrumentId=[long]`
      

*   **Optional:**
 
      `None`


* **Success Response:**
  
   * **Code:** 
   
            200 
   * **Content:** 
     
				{
				    "validDemand": 50,
				    "invalidDemand": 90,
				    "totalValidDemandCount": 1,
				    "totalInvalidDemandCount": 2,
				    "earliestOrder": {
				        "orderId": 1,
				        "instrumentId": 1234,
				        "quantity": 40,
				        "entryDate": "2019-04-13T02:33:39.129+0000",
				        "limitPrice": 16,
				        "orderType": "LIMIT_ORDER"
				    },
				    "lastOrder": {
				        "orderId": 3,
				        "instrumentId": 1234,
				        "quantity": 50,
				        "entryDate": "2019-04-13T02:33:39.129+0000",
				        "limitPrice": null,
				        "orderType": "MARKET_ORDER"
				    },
				    "biggestOrder": {
				        "orderId": 2,
				        "instrumentId": 1234,
				        "quantity": 50,
				        "entryDate": "2019-04-13T02:33:39.129+0000",
				        "limitPrice": 16,
				        "orderType": "LIMIT_ORDER"
				    },
				    "smallestOrder": {
				        "orderId": 1,
				        "instrumentId": 1234,
				        "quantity": 40,
				        "entryDate": "2019-04-13T02:33:39.129+0000",
				        "limitPrice": 16,
				        "orderType": "LIMIT_ORDER"
				    },
				    "limitPriceDemandMap": {
				        "16": 90
				    }
			}  
				    
* **Error Response:**
     
      None
  
* **Sample Call:**

    url: "/orderbook/1234/execstats 
        
* **Notes:**